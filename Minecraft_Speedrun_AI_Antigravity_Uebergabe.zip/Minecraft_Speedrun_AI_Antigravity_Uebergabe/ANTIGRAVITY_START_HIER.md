# ANTIGRAVITY – START HIER

Du erhältst die Historie und den neuesten Code der Minecraft Speedrun AI. Hauptstand: `AKTUELLER_PROJEKTCODE/MinecraftSpeedrunAI-v06/` (v0.6.0, kompletter Quellcode plus Fabric-JAR plus bereits trainierter Navigations-Checkpoint). Frühere Versionen und Patches unter `VERSIONEN_ORIGINAL_ZIPS/` nur zum Vergleich; NIEMALS unreflektiert auf v06 überschreiben.

**Lies zuerst:** `DOKUMENTATION/PROJEKTUEBERGABE.md`, `AKTUELLER_PROJEKTCODE/MinecraftSpeedrunAI-v06/README.md`, `AKTUELLER_PROJEKTCODE/MinecraftSpeedrunAI-v06/AUSWERTUNG-v052.md`, und `DOKUMENTATION/FEHLENDE_DATEIEN.md`.

**Dein konkreter Auftrag:**
1. Erfasse Komponenten, Einstiegspunkte, vorhandene Models und API zwischen Trainer/Mod. Prüfe, ob gemeldete Features tatsächlich im Code existieren; berichte Abweichungen knapp.
2. Führe eine **statische** Prüfung und die Unit-Tests aus und zeige echte Ergebnisse. Minecraft-Integration nur auf der vorgesehenen MSAI_LAB-Lokalwelt und nach Überprüfung der Pfade/Backup; niemals andere Spiele/Instanzen überschreiben.
3. Entwickle die neueste Holz-Challenge 4–6 weiter: führe sie bei vorhandener Minecraft-Umgebung aus, sammle echte Run-Logs. Prüfe Policy gegen Lehrer/Blind/Zufall und messe nach vorher festgelegten Gates. Ungetestete Stufen nicht als bestanden markieren.
4. Bei erfüllten Gates implementiere **unmittelbar** den nächsten neuen Fähigkeitsbereich inkl. Lernpolicy, neuem Experiment-Curriculum, automatische Tests, Auswertung, Checkpoints und Windows-CMD-Dateien (z. B. Bretter/Tisch craften, nicht nur alte Gold-Zielnavigation recyceln). Wenn der Block nicht bestanden wird, behebe die datenbasiert isolierte Ursache und teste erneut.
5. Nutze nach Möglichkeit vorhandene Netzgewichte und gemeinsame Schnittstellen, ohne Checkpoints zu zerstören. Sichere Änderungen mit Git und dokumentiere Migration.
6. Trenne Imitation-/RL-Training, trainierte Modelltest-Leistung, Lehrerergebnisse und synthetische Tests. Keine ausgedachten Messungen oder Zeitangaben.
7. Liefere zum Schluss wirklich veränderte Dateien, gegebenenfalls gebaute Mod-JAR, genaue Windows-Klickfolge, ausgeführte Tests + Ergebnisse und klaren nächsten Testauftrag.

**Wichtige Einschränkung:** Fünf historische Nutzer-Run-ZIPs und vollständige Roh-Chats konnten nicht automatisiert hineinkopiert werden. Die vollständigen Daten können nachträglich in `TESTDATEN_EINFUEGEN/` bzw. `CHATVERLAEUFE_OPTIONAL/` ergänzt werden; die fachliche Zusammenfassung ist auch ohne sie verwendbar.

Bitte beginne JETZT damit, den tatsächlichen Code zu lesen, lokal verfügbare Tests auszuführen und unmittelbar mit der Implementierung fortzufahren – nicht mit einer langen abstrakten neuen Planung.
