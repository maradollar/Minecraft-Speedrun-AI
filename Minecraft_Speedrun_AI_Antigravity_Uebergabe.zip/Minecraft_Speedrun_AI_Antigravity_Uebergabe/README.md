# Minecraft Speedrun AI – vollständiges verfügbares Antigravity-Übergabepaket

**Einstieg:** [`ANTIGRAVITY_START_HIER.md`](ANTIGRAVITY_START_HIER.md)  
**Ausführliche Dokumentation:** [`DOKUMENTATION/PROJEKTUEBERGABE.md`](DOKUMENTATION/PROJEKTUEBERGABE.md)  
**Aktueller Stand:** `AKTUELLER_PROJEKTCODE/MinecraftSpeedrunAI-v06/`  
**Originale frühere Pakete:** `VERSIONEN_ORIGINAL_ZIPS/` (8 ZIP-Dateien)  
**Verfügbarkeitsgrenzen:** [`DOKUMENTATION/FEHLENDE_DATEIEN.md`](DOKUMENTATION/FEHLENDE_DATEIEN.md)  
**ChatGPT-Export nachträglich einlesen:** `CHATVERLAEUFE_OPTIONAL/IMPORT_CHATS.cmd`  

Nicht verwechseln: README und rekonstruierte Historie sind keine vollständigen alten Chat-Protokolle. Die nicht abrufbaren Testdaten-ZIPs müssen separat hinzugefügt werden.
