@echo off
setlocal
cd /d "%~dp0"
call settings.cmd
if not exist "%MSAI_PY%" (
 echo Python not found. Edit settings.cmd.
 pause
 exit /b 1
)
"%MSAI_PY%" -m msai5.run evaluate --game-dir "%MSAI_GAME%" --checkpoint seed/navigation-v052.npz --output runs-v06/navigation-check --episodes 16 --test-start 710000 --stage 1
if errorlevel 1 (
 echo ERROR or interrupted. Read message above.
) else (
 echo Finished. Read result above.
)
pause
