"""Install only the MSAI JAR; preserve old mods and all model files."""
import argparse,json,os,shutil,time,zipfile
from pathlib import Path

def install(game):
 root=Path(game).resolve(strict=True);world=root/'saves'/'MSAI_LAB'
 if world.is_symlink() or not (world/'level.dat').is_file():raise RuntimeError('Expected existing dedicated MSAI_LAB world')
 if (world/'.msai-lab-consent').read_text().strip()!='MSAI_LAB_ALLOW_RESET_V1':raise RuntimeError('Lab not armed')
 if not (root/'config/msai.properties').is_file():raise RuntimeError('Missing existing connection configuration')
 source=Path(__file__).resolve().parents[1]/'dist/msai-0.6.0-mc26.3.jar'
 with zipfile.ZipFile(source) as z:
  meta=json.loads(z.read('fabric.mod.json'))
  if meta['id']!='msai' or meta['version']!='0.6.0' or z.testzip():raise RuntimeError('Invalid update JAR')
 with (world/'session.lock').open('r+b') as lock:
  try:
   if os.name=='nt':
    import msvcrt
    lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
   else:
    import fcntl
    fcntl.lockf(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except OSError:raise RuntimeError('Close Minecraft completely before installing. Do not remove session.lock.')
  mods=root/'mods';mods.mkdir(exist_ok=True);old=[]
  for jar in mods.glob('*.jar'):
   try:
    with zipfile.ZipFile(jar) as z:
     if 'fabric.mod.json' in z.namelist() and json.loads(z.read('fabric.mod.json')).get('id')=='msai':old.append(jar)
   except (zipfile.BadZipFile,ValueError):raise RuntimeError('Unreadable JAR in mods: '+jar.name)
  backup=root/'msai-mod-backups'/str(time.time_ns());backup.mkdir(parents=True)
  target=mods/source.name;temp=mods/(source.name+'.pending');shutil.copyfile(source,temp)
  moved=[]
  try:
   for jar in old:shutil.move(str(jar),str(backup/jar.name));moved.append(jar.name)
   temp.replace(target)
  except Exception:
   for name in moved:shutil.move(str(backup/name),str(mods/name))
   if temp.exists():temp.unlink()
   raise
 print('Installed:',target);print('Old MSAI mods preserved:',backup);print('Existing worlds, configuration and models preserved.')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--game-dir',default=r'C:\MC-AI\instance1');a=p.parse_args()
 try:install(a.game_dir)
 except Exception as ex:raise SystemExit(str(ex))
