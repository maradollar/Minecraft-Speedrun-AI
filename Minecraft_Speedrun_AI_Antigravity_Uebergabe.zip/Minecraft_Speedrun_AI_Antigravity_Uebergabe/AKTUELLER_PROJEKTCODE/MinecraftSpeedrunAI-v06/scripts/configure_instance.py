import argparse,secrets
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--game-dir',required=True);p.add_argument('--port',type=int,default=8765);a=p.parse_args()
if not 1024<=a.port<=65535:raise SystemExit('Invalid port')
root=Path(a.game_dir).resolve();config=root/'config/msai.properties'
if config.exists():raise SystemExit('Already configured. Do not change token while Minecraft is running.')
config.parent.mkdir(parents=True,exist_ok=True);(root/'mods').mkdir(exist_ok=True);config.write_text(f'port={a.port}\ntoken={secrets.token_hex(24)}\n',encoding='ascii');print('Prepared',root,'port',a.port)
