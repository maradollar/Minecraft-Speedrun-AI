"""Consent for resetting only a separately created lab. Close Minecraft first."""
import argparse,os
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--game-dir',required=True);a=p.parse_args();root=Path(a.game_dir).resolve(strict=True);saves=(root/'saves').resolve(strict=True);world=saves/'MSAI_LAB'
if world.is_symlink() or world.resolve(strict=True).parent!=saves or not (world/'level.dat').is_file():raise SystemExit('Expected a new, separate MSAI_LAB world, no symlink')
with (world/'session.lock').open('a+b') as lock:
 try:
  if os.name=='nt':
   import msvcrt
   lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
  else:
   import fcntl
   fcntl.lockf(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except OSError:raise SystemExit('World still open. Close Minecraft; never delete session.lock.')
 (world/'.msai-lab-consent').write_text('MSAI_LAB_ALLOW_RESET_V1\n',encoding='utf-8')
print('Armed lab:',world)
