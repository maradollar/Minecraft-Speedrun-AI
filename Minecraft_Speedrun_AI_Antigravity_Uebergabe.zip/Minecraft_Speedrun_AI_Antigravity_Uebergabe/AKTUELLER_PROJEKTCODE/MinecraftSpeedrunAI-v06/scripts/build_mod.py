"""Pinned direct javac build. No Gradle/remapping needed for this 26.3 mod."""
import argparse,hashlib,json,os,shutil,subprocess,urllib.request,zipfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--jdk');p.add_argument('--cache');p.add_argument('--offline',action='store_true');a=p.parse_args()
home=a.jdk or os.environ.get('JAVA_HOME');javac=str(Path(home)/'bin'/('javac.exe' if os.name=='nt' else 'javac')) if home else shutil.which('javac')
if not javac:raise SystemExit('Install JDK 25 or pass --jdk PATH')
r=subprocess.run([javac,'-version'],capture_output=True,text=True,check=True)
if not (r.stdout+r.stderr).strip().startswith('javac 25'):raise SystemExit('JDK 25 required')
cache=Path(a.cache).resolve() if a.cache else ROOT/'.build-cache';cache.mkdir(exist_ok=True)
def fetch(e):
 path=cache/e['file']
 if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==e['sha256']:return path
 if a.offline:raise RuntimeError('Missing cache: '+e['file'])
 print('Download',e['file'],flush=True);temp=path.with_suffix('.download')
 with urllib.request.urlopen(e['url'],timeout=120) as src,temp.open('wb') as out:shutil.copyfileobj(src,out)
 if hashlib.sha256(temp.read_bytes()).hexdigest()!=e['sha256']:temp.unlink();raise RuntimeError('Checksum mismatch: '+e['file'])
 temp.replace(path);return path
lock=json.loads((ROOT/'mod/dependencies.lock.json').read_text())
with ThreadPoolExecutor(max_workers=6) as pool:jars=list(pool.map(fetch,lock))
classes=cache/'classes'
if classes.exists():shutil.rmtree(classes)
classes.mkdir()
def quote(v):return '"'+str(v).replace('\\','/').replace('"','\\"')+'"'
args=['-proc:none','--release','25','-encoding','UTF-8','-classpath',quote(os.pathsep.join(map(str,jars))),'-d',quote(classes)]+[quote(x) for x in sorted((ROOT/'mod/src/main/java').rglob('*.java'))]
argfile=cache/'javac.args';argfile.write_text('\n'.join(args),encoding='utf-8');subprocess.run([javac,'@'+str(argfile)],check=True)
jar=ROOT/'dist/msai-0.6.0-mc26.3.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
 for base in [classes,ROOT/'mod/src/main/resources']:
  for file in sorted(base.rglob('*')):
   if file.is_file():
    info=zipfile.ZipInfo(file.relative_to(base).as_posix(),(2026,10,15,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,file.read_bytes())
print('Built',jar);print('SHA256',hashlib.sha256(jar.read_bytes()).hexdigest())
