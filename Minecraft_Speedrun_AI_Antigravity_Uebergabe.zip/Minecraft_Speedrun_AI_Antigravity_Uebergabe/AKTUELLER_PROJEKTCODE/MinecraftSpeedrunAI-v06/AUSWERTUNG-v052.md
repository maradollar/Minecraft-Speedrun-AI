# Auswertung der eingesandten reliability-v052.zip

Quelle: before/after episodes.csv, actions.csv, summary.json sowie result.json.

| Ziel | Vorher | Nachher |
|---|---:|---:|
| Gold | 6/8 | 8/8 |
| Eisen | 4/8 | 4/8 |
| Smaragd | 8/8 | 8/8 |
| Eiche | 7/8 | 8/8 |
| Gesamt | 25/32 (78,1 %) | 28/32 (87,5 %) |

Alle 32 Prüfungen sind abgeschlossen. Die Gewichts-Hashes bleiben in beiden Evaluierungen unverändert. Das Training aktualisiert die Gewichte und erreicht 32/32 unterstützte Erfolge; das ist keine autonome Erfolgsquote.

Die mittlere Spielzeit sinkt von 7,90 auf 5,15 Sekunden. Richtungswechsel sinken von 743 auf 465, aber zugleich sinkt die Aktionszahl von 2208 auf 1419. Der Quotient Wechsel/Aktionen ändert sich nur von 33,7 auf 32,8 Prozent. Die reine Gesamtzahl belegt daher noch keine deutliche Verbesserung der Feinsteuerung.

Eisen scheitert vorher in Szenarien 220003/220004/220005/220006 und nachher in 220000/220001/220003/220006. Zwei Fälle werden verbessert, zwei andere verschlechtert. Deshalb kein weiterer identischer Eisen-Trainingsblock und keine Behauptung einer allgemein stabilen Navigation.

Eiche hat in diesem kleinen Vergleich 8/8 Erfolge. Das reicht als Grundlage für die Entwicklung einer getrennt prüfbaren Holzfähigkeit, nicht als Beweis für unbegrenzte Zuverlässigkeit. Das v06-Paket übernimmt den Bildkern, schützt das Navigationsmodell und ergänzt die schwierigeren Aufgaben Zielen/Abbauen/Aufnehmen mit neuen Starts und Kontrollen.

Empfehlung für spätere Eisen-Diagnose: gelabelte Bilder der vier Fehlersituationen prüfen, visuellen Zielpunkt explizit überwachen und mit feinerer Regelung vergleichen. Eine pauschale Glättung oder weitere identische Trainingsblöcke sind aus diesen Daten nicht begründet. Dieser Umbau ist im Holzpaket nicht als erledigt ausgewiesen.
