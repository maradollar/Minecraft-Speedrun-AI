import base64,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from msai5.core import Learner as Old,VisionHistory as OldHistory
from msai6.core import Learner,VisionHistory,PIXELS,SCHEMA,TICKS
from msai6.skill import transfer,ResourceSkill
from msai6.teacher import Teacher
from challenge import promotion
ROOT=Path(__file__).resolve().parents[1]
def image():return base64.b64encode(np.random.default_rng(7).integers(0,256,(36,64,3),dtype='u1').tobytes()).decode()
class Tests(unittest.TestCase):
 def test_transfer_keeps_visual_hidden_features(self):
  old,_=Old.load(ROOT/'seed/navigation-v052.npz');new,_=transfer(ROOT/'seed/navigation-v052.npz')
  rgb=image();xo=OldHistory().encode(rgb,'oak_log',1);xn=VisionHistory().encode(rgb,'oak_log',1)
  ho,_,_=old.forward(xo);hn,_,_=new.forward(xn)
  np.testing.assert_allclose(ho,hn,atol=2e-6)
  np.testing.assert_array_equal(old.p['wc'],new.p['wc'])
 def test_all_seven_actions_have_gradient(self):
  m,_=transfer(ROOT/'seed/navigation-v052.npz');x=VisionHistory().encode(image(),'oak_log')
  old=m.p['wc'].copy();metrics=m.imitate(np.tile(x,(7,1)),np.arange(7),batches=3)
  self.assertTrue(metrics['changed']);self.assertFalse(np.array_equal(old,m.p['wc']))
  self.assertEqual(m.forward(x)[1].shape,(1,7))
 def test_checkpoint_roundtrip(self):
  m,meta=transfer(ROOT/'seed/navigation-v052.npz')
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'test.npz';m.save(p,meta);restored,extra=Learner.load(p)
   self.assertEqual(restored.digest(),m.digest());self.assertEqual(extra['schema'],SCHEMA)
 def test_policy_has_no_teacher_dependency(self):
  m,_=transfer(ROOT/'seed/navigation-v052.npz');skill=ResourceSkill(m)
  with patch.object(Teacher,'label',side_effect=AssertionError('Teacher used')):
   result=skill.decide(image());self.assertIn(result['name'],['forward','left','right','up','down','mine','back'])
 def test_image_input_rejects_state_dictionary(self):
  with self.assertRaises(TypeError):VisionHistory().encode({'rgb':image(),'x':3},'oak_log')
 def test_mining_teacher(self):
  a=dict(x=.5,y=200,z=.5,yaw=0,pitch=4.57,visible_logs=[dict(x=.5,y=201.5,z=2)],crosshair_log=True)
  self.assertEqual(Teacher().label(a),5)
  a['pitch']=25;self.assertEqual(Teacher().label(a),3)
  a['pitch']=-10;self.assertEqual(Teacher().label(a),4)
 def test_success_gate_requires_image_advantage(self):
  def s(n):return dict(completed=12,interrupted=False,successes=n)
  self.assertTrue(promotion(s(11),s(6),s(5)))
  self.assertFalse(promotion(s(11),s(10),s(5)))
  self.assertFalse(promotion(s(8),s(0),s(0)))
 def test_attack_is_long_enough_and_within_bridge_limit(self):
  self.assertGreaterEqual(TICKS[5],60);self.assertLessEqual(max(TICKS),80)
 def test_fake_episode_learning_then_unaided_eval(self):
  import os
  from msai6 import run
  a=dict(rgb=image(),x=.5,y=200,z=.5,yaw=0,pitch=4.57,visible_logs=[dict(x=.5,y=201.5,z=2)],crosshair_log=True)
  class Client:
   def __init__(self,*args):pass
   def stop(self):pass
   def call(self,path,data=None):
    if path=='/health':return dict(version='0.6.0')
    return dict(agent=a,trainer=dict(success=path=='/step',dead=False,collected=int(path=='/step'),remaining_logs=1,distance=1.5))
  class Fresh:
   def __init__(self,*args):pass
   def fresh(self,r):return r
  old=Path.cwd()
  with tempfile.TemporaryDirectory() as d,patch.object(run,'Client',Client),patch.object(run,'LabEnv',Fresh):
   os.chdir(d)
   try:
    Path('seed').mkdir();import shutil;shutil.copy2(ROOT/'seed/navigation-v052.npz','seed/navigation-v052.npz')
    run.main(['learn','--episodes','1']);m,meta=Learner.load('runs-v06/resource.npz');h=m.digest()
    self.assertEqual(meta['episodes'],1)
    with patch.object(Teacher,'label',side_effect=AssertionError('Teacher called in evaluation')):run.main(['evaluate','--episodes','1'])
    self.assertEqual(Learner.load('runs-v06/resource.npz')[0].digest(),h)
   finally:os.chdir(old)
if __name__=='__main__':unittest.main()
