@echo off
set "MSAI_GAME=C:\MC-AI\instance1"
set "MSAI_PY=%~dp0..\MinecraftSpeedrunAI\.venv\Scripts\python.exe"
set "PYTHONPATH=%~dp0trainer"
