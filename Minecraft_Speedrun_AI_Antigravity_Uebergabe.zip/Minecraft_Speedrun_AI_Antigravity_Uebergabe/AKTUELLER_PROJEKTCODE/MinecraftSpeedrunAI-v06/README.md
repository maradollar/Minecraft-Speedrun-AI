# Minecraft Speedrun AI 0.6.0 – Holz beschaffen

Dieses Paket implementiert die nächste Lernfähigkeit: Eichenholz anhand der Spielbilder ansteuern, passend ausrichten, mit der Hand abbauen und mindestens einen Holzgegenstand aufnehmen. Es enthält den vollständigen Quellcode, eine gebaute Fabric-JAR und den Navigationslernstand aus deinem eingesandten v052-Test. Kein bereits trainierter Holz-Agent; die neue Fähigkeit muss auf deinem PC lernen.

## 1. Installation unter Windows

1. Trainer und Bildvorschau beenden. Minecraft vollständig schließen.
2. ZIP mit Rechtsklick → „Alle extrahieren“ nach `C:\MC-AI` entpacken.
3. Den neuen Ordner `C:\MC-AI\MinecraftSpeedrunAI-v06` öffnen. Darin liegen direkt die CMD-Dateien. Nicht in v05 hineinkopieren.
4. `settings.cmd` bei Bedarf mit dem Editor öffnen:
   - `MSAI_GAME=C:\MC-AI\instance1` ist deine bisherige Minecraft-Installation.
   - `MSAI_PY` zeigt weiterhin auf `C:\MC-AI\MinecraftSpeedrunAI\.venv\Scripts\python.exe`.
   - Die bestehende Python-Umgebung enthält NumPy und Pillow; keine GPU-Installation nötig.
5. `00_INSTALLIEREN.cmd` doppelklicken. Der Installer prüft die vorhandene markierte MSAI_LAB-Welt und sichert die alte MSAI-Mod in `instance1\msai-mod-backups`. Andere Mods werden nicht ersetzt. Bei Fehlern nicht fortfahren.
6. Dieselbe Minecraft-Trainingsinstallation wie bisher starten und **MSAI_LAB** öffnen. Version weiterhin Minecraft 26.3 / Fabric Loader 0.19.5 / Java 25; das ist die Version deiner bisherigen gebauten Mod.
7. Standardtexturen, keine Shader, FOV 90 verwenden. Chat, Inventar und Pause-Menü schließen. Minecraft sichtbar lassen und nicht selbst steuern.
8. Optional `02_BILDVORSCHAU.cmd` öffnen. Das Fenster zeigt das tatsächlich verwendete 64×36-Spielbild vergrößert, keine zusätzliche Detailauflösung. Es wartet auf die erste Trainingsepisode.
9. **`01_HOLZ_CHALLENGES.cmd` starten.** Nur einen Trainer gleichzeitig öffnen.

Keine alten Modelle verschieben oder löschen. Die Navigationsgewichte sind als unveränderte Kopie `seed/navigation-v052.npz` enthalten. Der neue Lernstand entsteht unter `runs-v06/resource.npz`.

## 2. Der automatische Ablauf

| Stufe | Neue Aufgabe | Unterschied |
|---|---|---|
| 4 – Abbau | Nahen Eichenstamm anvisieren, abbauen, aufnehmen | Unterschiedliche Blickhöhen und ein-/zweistöckige Stämme; Hände statt Werkzeug |
| 5 – Beschaffung | Erst aus etwa fünf Blöcken Entfernung heranlaufen, dann abbauen und aufnehmen | Verknüpft Bewegung und Interaktion in derselben visuellen Politik |
| 6 – Auswahl | Eiche zwischen Gold-, Eisen- und Smaragdblöcken finden und beschaffen | Wechselnde Anordnung, mehr Blickabweichung und größere Entfernung |

Pro Stufe:

1. Vier **programmierte Helfertests**. Nur bei 4/4 geht es weiter. Sie testen zunächst, ob die Umgebung und die Beispielsaktionen funktionieren.
2. 40 Lernepisoden. Die ersten zwölf der Stufe führt der Helfer; danach übernimmt das Modell zunehmend selbst. Für seine beobachteten Situationen erhält es weiterhin Lehrerlabels (Nachahmungslernen).
3. Zwölf neue Prüfungen mit dem Modell ohne Helfereingriff.
4. Dieselben zwölf Starts mit schwarzen Bildern und mit Zufallssteuerung.
5. Mindestens 10/12 Modell-Erfolge und mindestens drei Erfolge Vorsprung gegenüber beiden Kontrollen sind für den nächsten Schritt erforderlich.
6. Ab Stufe 5 wird zusätzlich jede bereits bestandene Holzstufe erneut zwölfmal geprüft. Auch dort müssen mindestens zehn Erfolge bleiben.

Bei Fehlschlag hält die Pipeline an und speichert die Ergebnisse. Sie trainiert nicht unbegrenzt weiter. Bei Bestehen wechselt sie selbstständig zur nächsten Stufe. Zwölf Tests sind eine praktische Entwicklungsschwelle und kein statistischer Beweis für allgemeine Zuverlässigkeit.

**Erfolg bedeutet: mindestens ein Eichenholz-Item im Inventar.** Nur vor dem Stamm stehen oder ihn verschwinden lassen genügt nicht. Es gibt keine per Befehl gegebenen Holzitems. Abbauen läuft im Survival-Modus über die normale Angriffstaste.

## 3. Was lernt / was ist programmiert?

- Modelleingang: zwei RGB-Spielbilder, Zielauftrag Eichenholz und letzte eigene Aktion. Keine Weltkoordinaten, Inventarliste, Sichtstrahlen oder Block-IDs als Policy-Eingang. Das normale HUD ist Teil des Bildes.
- Gelernt: Bildfilter, Zuordnung der Bilder zu Bewegung, Blickkorrektur und Abbauaktion. Das Modell hat sieben Aktionen: vorwärts, links/rechts drehen, hoch/runter schauen, abbauen, rückwärts.
- Programmiert: Bedeutung und Dauer der Tastenaktionen, Trainingswelten, Reset, Helferlabels und Erfolgsmessung. Die Abbauaktion hält die Taste 70 Spielticks (3,5 Sekunden bei 20 TPS); das Modell entscheidet, **wann** sie benutzt wird, nicht ihre Dauer.
- Der Helfer darf sichtbare Blocktreffer und Spielerposition verwenden. Nur Training/Helfertest erzeugen damit Labels. Im eigenständigen Test wird der Helfer nicht instanziiert.
- Das normale Training ist Nachahmungslernen. Diese Holzversion führt kein zusätzliches Belohnungslernen aus.
- Der neue Kopf und die Aktionshistorie werden erweitert; Bildfilter und passende versteckte Gewichte kommen aus deinem v052-Modell. Alte Navigationsgewichte werden nicht überschrieben. Tests prüfen, dass die übertragenen versteckten Bildrepräsentationen vor dem neuen Training identisch sind.
- Eine separate höher aufgelöste Wahrnehmung und langfristiges Gedächtnis sind hier nicht implementiert. Die Auflösung bleibt absichtlich kompatibel mit dem vorhandenen Bildmodell. Bei Problemen prüfen wir Erkennung, Zielen und Itemaufnahme getrennt anhand der Protokolle.

Die Fähigkeit `trainer/msai6/skill.py:ResourceSkill` nimmt nur Bilder entgegen und liefert Aktion plus Dauer zurück. Spätere Auftragssteuerung kann sie als Fähigkeit „beschaffe Eichenholz“ aufrufen; Erfolg/Abbruch bewertet die Umgebung separat. Stufe 5 verbindet Navigation und Abbau innerhalb dieser Politik durch übernommene Gewichte und gemeinsames Training, nicht durch heimliches Zuschalten des alten Helfers.

## 4. Speichern, Pause, Fortsetzen

- Nach jeder abgeschlossenen Episode werden Modell und Beispieldaten gespeichert.
- Normal stoppen: einmal `Strg+C` im Trainer drücken und die Speichermeldung abwarten. Eine laufende Abbauaktion kann noch einige Sekunden dauern.
- Notstopp: `04_STOP.cmd`, anschließend Trainer beenden. Ein offenes Minecraft-Menü löst ebenfalls den Steuerungswächter aus.
- Erneut `01_HOLZ_CHALLENGES.cmd` lädt den vorhandenen Stand. Bereits bestandene Stufen werden übersprungen; fehlende Episoden bis 40 ergänzt. Nach einem abgeschlossenen, gescheiterten Test erzeugt erneutes Starten **keine** weiteren 40 Episoden – erst die Ergebnisse auswerten.
- Checkpoints bestandener Stufen: `runs-v06/passed-stage4.npz` usw.
- Ergebnisübersicht: `runs-v06/result.json`. Die Unterordner enthalten Aktionen, Erfolg, eingesammelte Items, noch stehende Holzblöcke, Laufzeiten, Gewichts-Hashes und Lehreranteil.
- Danach **den gesamten Ordner `runs-v06` als ZIP hochladen**. Darin ist alles für die nächste Analyse enthalten. Nicht den `instance1/config`-Ordner mit Zugangstoken hochladen.

## 5. Dauer und nächste Entscheidungen

Die Abbauaufgabe dauert länger als reine Navigation. Die erste Lernepisode misst bereits Reset, Aktionen, Training und Speichern; danach zeigt der Trainer eine Restzeitschätzung für den aktuellen Block. Ein Versuch endet spätestens nach ungefähr 90 Sekunden plus der laufenden Aktion. Blind- und Zufallstests können deshalb jeweils etwa 18 Minuten dauern. Mehrere Stufen können insgesamt deutlich länger als eine Stunde brauchen; bei einem Gate-Fehler stoppt der Ablauf früher. Es gibt keine belegbare Vorhersage, nach wie vielen Episoden die Holzfähigkeit gelernt ist.

Fehler werden getrennt lesbar: noch stehende Holzblöcke bei Timeout → Suchen/Zielen/Abbauen untersuchen; keine Holzblöcke, aber kein Item → Aufnahme untersuchen. Lehrertests müssen zunächst erfolgreich sein, bevor Modelltraining sinnvoll ist.

Nach Bestehen aller drei Stufen folgt als eigener Ausbau natürliches Gelände mit Bäumen und Hindernissen, dann Holzverarbeitung/Crafting. Beides ist noch nicht enthalten. Eisen-Navigation bleibt ein offener separater Diagnosepunkt; ihr Ergebnis wird nicht als gelöst dargestellt.

## 6. Navigation und technische Prüfung

`03_NAVIGATION_KONTROLLE.cmd` prüft den eingefrorenen v052-Navigationsstand auf 16 bisher nicht verwendeten Zielaufträgen (vier pro Blocktyp), mit unveränderter Policy. Separat starten, wenn kein Holztrainer läuft. Dies verändert das Holzmodell nicht.

`05_CODETEST.cmd` führt neun automatisierte Tests aus. Sie prüfen Gewichtsübernahme, Gradienten aller Aktionsklassen, Speichern/Laden, den bildbasierten Eingabevertrag, Helfertrennung, Curriculum-Gates, Aktionsdauer und einen simulierten Lern-/Testdurchlauf. Die Simulation prüft Programmlogik, **keinen Minecraft-Lernerfolg**.

Die JAR wurde hier mit JDK 25 gebaut. Minecraft selbst und Windows können hier nicht end-to-end getestet werden. Der zuerst laufende Helfertest ist deshalb wichtig. Für einen reproduzierbaren eigenen Build: JDK 25 installieren und `python scripts/build_mod.py --jdk "PFAD_ZUM_JDK"` ausführen; Abhängigkeiten sind über `mod/dependencies.lock.json` festgelegt. Du brauchst zum normalen Spielen keinen Build.

Zurück zur v05-Mod: Minecraft schließen, neue MSAI-JAR aus `instance1/mods` entfernen und die gesicherte alte MSAI-JAR zurückkopieren. Immer nur eine MSAI-JAR gleichzeitig verwenden. Die v05-Ordner und Lernstände bleiben erhalten.
