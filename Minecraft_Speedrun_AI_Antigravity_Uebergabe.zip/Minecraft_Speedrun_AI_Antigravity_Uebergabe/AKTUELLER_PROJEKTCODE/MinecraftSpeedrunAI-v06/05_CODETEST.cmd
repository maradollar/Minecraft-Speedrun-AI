@echo off
setlocal
cd /d "%~dp0"
call settings.cmd
if not exist "%MSAI_PY%" (
 echo Python not found. Edit settings.cmd.
 pause
 exit /b 1
)
"%MSAI_PY%" -m unittest discover -s tests -v
if errorlevel 1 (
 echo ERROR or interrupted. Read message above.
) else (
 echo Finished. Read result above.
)
pause
