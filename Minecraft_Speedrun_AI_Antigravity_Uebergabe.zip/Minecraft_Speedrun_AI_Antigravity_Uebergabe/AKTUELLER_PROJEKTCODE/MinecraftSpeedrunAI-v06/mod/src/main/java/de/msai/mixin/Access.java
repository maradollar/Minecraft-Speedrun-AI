package de.msai.mixin;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
@Mixin(value=Minecraft.class,remap=false)
public interface Access {
 @Invoker("startAttack") boolean attack();
 @Invoker("continueAttack") void attackHeld(boolean held);
 @Invoker("startUseItem") void use();
}
