package de.msai.mixin;
import de.msai.Bridge;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=Minecraft.class,remap=false)
public class TickMixin {
 @Inject(method="tick",at=@At("HEAD")) private void before(CallbackInfo ci){Bridge.before();}
 @Inject(method="tick",at=@At("RETURN")) private void after(CallbackInfo ci){Bridge.after();}
 @Inject(method="close",at=@At("HEAD")) private void close(CallbackInfo ci){Bridge.shutdown();}
}
