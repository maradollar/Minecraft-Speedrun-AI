package de.msai;
import com.google.gson.*;
import com.sun.net.httpserver.*;
import de.msai.mixin.Access;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.*;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.Difficulty;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.*;
import java.net.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Local-only laboratory bridge; no arbitrary commands or survival-run mode. */
public class Bridge implements ClientModInitializer {
 static final Gson JSON=new Gson();
 static final ConcurrentLinkedQueue<Runnable> QUEUE=new ConcurrentLinkedQueue<>();
 static final AtomicBoolean BUSY=new AtomicBoolean(),CAPTURING=new AtomicBoolean();
 static final AtomicLong EPOCH=new AtomicLong();
 static HttpServer http; static ExecutorService workers; static String token,world="";
 static volatile boolean controlled,stopped;
 static boolean oldPause;
 static volatile long tick,contact=System.nanoTime();
 static long lastCapture,frameNumber;
 static volatile String imageError="";
 static volatile Frame frame;
 static volatile Action current=new Action();
 static int remaining;
 static CompletableFuture<JsonObject> pending;
 static volatile Lab lab;
 record Frame(String rgb,long number,long tick,long nano){}
 record Lab(long scenario,double x,double z,int start,String goal,int stage){}
 static final String[] GOALS={"gold_block","iron_block","emerald_block","oak_log"};
 static final net.minecraft.world.level.block.Block[] TARGETS={Blocks.GOLD_BLOCK,Blocks.IRON_BLOCK,Blocks.EMERALD_BLOCK,Blocks.OAK_LOG};
 public static class Action {
  public boolean forward,back,left,right,jump,sneak,sprint,attack,use;
  public float yaw,pitch; public int hotbar=-1;
 }
 static Minecraft mc(){return Minecraft.getInstance();}
 public static Action action(){return controlled?current:new Action();}
 static JsonObject object(String k,String v){var o=new JsonObject();o.addProperty(k,v);return o;}
 public void onInitializeClient(){
  try{
   Path path=mc().gameDirectory.toPath().resolve("config/msai.properties");Files.createDirectories(path.getParent());
   Properties p=new Properties();if(Files.exists(path))try(var r=Files.newBufferedReader(path)){p.load(r);}
   p.putIfAbsent("port","8765");p.putIfAbsent("token",UUID.randomUUID().toString());
   try(var w=Files.newBufferedWriter(path)){p.store(w,"Local training bridge; keep token private");}
   token=p.getProperty("token");int port=Integer.parseInt(p.getProperty("port"));
   if(port<1024||port>65535||token.length()<20)throw new IllegalArgumentException("Invalid config");
   http=HttpServer.create(new InetSocketAddress("127.0.0.1",port),8);
   workers=Executors.newFixedThreadPool(4,r->{var t=new Thread(r,"MSAI-HTTP");t.setDaemon(true);return t;});
   http.setExecutor(workers);http.createContext("/",Bridge::request);http.start();
   System.out.println("[MSAI] ready 127.0.0.1:"+port+"; only marked MSAI_LAB allowed");
  }catch(Exception e){System.err.println("[MSAI] START FAILED: "+e);}
 }
 static void reply(HttpExchange e,int code,JsonObject o)throws Exception{
  byte[] b=JSON.toJson(o).getBytes(StandardCharsets.UTF_8);e.getResponseHeaders().set("Content-Type","application/json");e.getResponseHeaders().set("Cache-Control","no-store");e.sendResponseHeaders(code,b.length);try(var out=e.getResponseBody()){out.write(b);}
 }
 static void request(HttpExchange e){
  boolean owner=false;
  try{
   if(!("Bearer "+token).equals(e.getRequestHeaders().getFirst("Authorization"))){reply(e,401,object("error","Unauthorized"));return;}
   if(!e.getRequestMethod().equals("POST")){reply(e,405,object("error","POST required"));return;}
   byte[] bytes=e.getRequestBody().readNBytes(16385);if(bytes.length>16384)throw new IllegalArgumentException("Oversized request");
   var b=bytes.length==0?new JsonObject():JsonParser.parseString(new String(bytes,StandardCharsets.UTF_8)).getAsJsonObject();
   String path=e.getRequestURI().getPath();contact=System.nanoTime();
   if(path.equals("/health")){var o=object("version","0.6.0");o.addProperty("protocol",1);o.addProperty("minecraft","26.3");o.addProperty("image_error",imageError);reply(e,200,o);return;}
   if(path.equals("/stop")){stopped=true;current=new Action();EPOCH.incrementAndGet();QUEUE.add(()->release("User stop"));reply(e,200,object("status","stop requested"));return;}
   if(!BUSY.compareAndSet(false,true)){reply(e,409,object("error","Instance busy"));return;}owner=true;
   var f=new CompletableFuture<JsonObject>();long epoch=EPOCH.get();
   QUEUE.add(()->{try{
    if(epoch!=EPOCH.get())throw new IllegalStateException("Cancelled");guard();
    switch(path){
     case "/observe" -> f.complete(observe());
     case "/reset" -> reset(b,f,epoch);
     case "/inventory" -> {inventory(b);f.complete(observe());}
     case "/step" -> {
      if(lab==null||stopped)throw new IllegalStateException("Reset lab first");
      if(mc().gui.screen()!=null)throw new IllegalStateException("Close menu first");
      var a=JSON.fromJson(b.getAsJsonObject("action"),Action.class);int ticks=b.has("ticks")?b.get("ticks").getAsInt():4;
      if(a==null||ticks<1||ticks>80||!Float.isFinite(a.yaw)||!Float.isFinite(a.pitch)||Math.abs(a.yaw)>90||Math.abs(a.pitch)>90||a.hotbar< -1||a.hotbar>8)throw new IllegalArgumentException("Invalid action");
      acquire();a.yaw/=ticks;a.pitch/=ticks;current=a;remaining=ticks;pending=f;
      if(a.hotbar>=0)mc().player.getInventory().setSelectedSlot(a.hotbar);
      if(a.attack)((Access)mc()).attack();if(a.use)((Access)mc()).use();
     }
     default -> throw new IllegalArgumentException("Unknown endpoint");
    }
   }catch(Throwable ex){release("Request failed");f.completeExceptionally(ex);}});
   reply(e,200,f.get(30,TimeUnit.SECONDS));
  }catch(Exception ex){stopped=true;current=new Action();EPOCH.incrementAndGet();QUEUE.add(()->release("HTTP error"));try{reply(e,400,object("error",String.valueOf(ex.getCause()!=null?ex.getCause():ex)));}catch(Exception ignored){}}
  finally{if(owner)BUSY.set(false);e.close();}
 }
 static void guard()throws Exception{
  var m=mc();var s=m.getSingleplayerServer();
  if(s==null||m.player==null||m.level==null||s.isPublished())throw new IllegalStateException("Only unpublished local singleplayer allowed");
  Path root=s.getWorldPath(LevelResource.ROOT).toRealPath(),saves=m.gameDirectory.toPath().resolve("saves").toRealPath();
  if(!root.getParent().equals(saves)||!root.getFileName().toString().equals("MSAI_LAB")||!s.getWorldData().getLevelName().equals("MSAI_LAB"))throw new IllegalStateException("Open dedicated MSAI_LAB");
  Path marker=root.resolve(".msai-lab-consent");if(!Files.isRegularFile(marker)||!Files.readString(marker).trim().equals("MSAI_LAB_ALLOW_RESET_V1"))throw new IllegalStateException("Run arm_world.py while Minecraft is closed");
  if(!m.level.dimension().equals(Level.OVERWORLD))throw new IllegalStateException("Overworld only");
  if(!world.equals(root.toString())){lab=null;world=root.toString();}
 }
 static void acquire(){if(!controlled){oldPause=mc().options.pauseOnLostFocus;mc().options.pauseOnLostFocus=false;controlled=true;mc().player.input=new AgentInput();}}
 static void neutral(){
  current=new Action();if(controlled&&mc().player!=null)mc().player.input.tick();
  if(mc().player!=null&&mc().gameMode!=null)((Access)mc()).attackHeld(false);
  for(var key:List.of(mc().options.keyUp,mc().options.keyDown,mc().options.keyLeft,mc().options.keyRight,mc().options.keyJump,mc().options.keyShift,mc().options.keySprint,mc().options.keyAttack,mc().options.keyUse))key.setDown(false);
 }
 static void release(String why){neutral();if(controlled){if(mc().player!=null)mc().player.input=new KeyboardInput(mc().options);mc().options.pauseOnLostFocus=oldPause;}controlled=false;remaining=0;if(pending!=null){pending.completeExceptionally(new IllegalStateException(why));pending=null;}}
 public static void before(){
  tick++;
  if(controlled&&(mc().player==null||mc().getSingleplayerServer()==null||mc().gui.screen()!=null||System.nanoTime()-contact>5_000_000_000L)){stopped=true;release("Watchdog/menu/world closed");}
  Runnable r;while((r=QUEUE.poll())!=null)r.run();
  if(controlled&&remaining>0&&mc().player!=null){var p=mc().player;p.setYRot(p.getYRot()+current.yaw);p.setXRot(Math.max(-89,Math.min(89,p.getXRot()+current.pitch)));p.setSprinting(current.sprint);mc().options.keyAttack.setDown(current.attack);mc().options.keyUse.setDown(current.use);if(current.attack)((Access)mc()).attackHeld(true);}
 }
 public static void after(){if(controlled&&remaining>0&&--remaining==0){neutral();var f=pending;pending=null;if(f!=null)try{f.complete(observe());}catch(Exception ex){f.completeExceptionally(ex);}}}
 public static void capture(){
  if(!controlled||System.nanoTime()-lastCapture<100_000_000L||!CAPTURING.compareAndSet(false,true))return;
  lastCapture=System.nanoTime();long t=tick;
  try{Screenshot.takeScreenshot(mc().gameRenderer.mainRenderTarget(),im->{try(im){byte[] rgb=new byte[64*36*3];int i=0;for(int y=0;y<36;y++)for(int x=0;x<64;x++){int c=im.getPixel(Math.min(im.getWidth()-1,(2*x+1)*im.getWidth()/128),Math.min(im.getHeight()-1,(2*y+1)*im.getHeight()/72));rgb[i++]=(byte)(c>>16);rgb[i++]=(byte)(c>>8);rgb[i++]=(byte)c;}frame=new Frame(Base64.getEncoder().encodeToString(rgb),++frameNumber,t,System.nanoTime());imageError="";}catch(Exception ex){imageError=ex.toString();}finally{CAPTURING.set(false);}});}catch(Exception ex){imageError=ex.toString();CAPTURING.set(false);}
 }
 static JsonObject stack(net.minecraft.world.item.ItemStack s){var j=object("item",BuiltInRegistries.ITEM.getKey(s.getItem()).toString());j.addProperty("count",s.getCount());return j;}
 static JsonObject observe(){
  var m=mc();var p=m.player;var j=new JsonObject();j.addProperty("tick",tick);j.addProperty("world",world);var a=new JsonObject();
  a.addProperty("x",p.getX());a.addProperty("y",p.getY());a.addProperty("z",p.getZ());a.addProperty("yaw",p.getYRot());a.addProperty("pitch",p.getXRot());a.addProperty("health",p.getHealth());a.addProperty("food",p.getFoodData().getFoodLevel());a.addProperty("alive",p.isAlive());a.addProperty("vx",p.getDeltaMovement().x);a.addProperty("vy",p.getDeltaMovement().y);a.addProperty("vz",p.getDeltaMovement().z);a.addProperty("selected",p.getInventory().getSelectedSlot());
  var inv=new JsonArray();for(int i=0;i<p.getInventory().getContainerSize();i++)inv.add(stack(p.getInventory().getItem(i)));a.add("inventory",inv);
  a.addProperty("screen",m.gui.screen()==null?"":m.gui.screen().getClass().getSimpleName());a.addProperty("container_id",p.containerMenu.containerId);var slots=new JsonArray();for(var slot:p.containerMenu.slots)slots.add(stack(slot.getItem()));a.add("slots",slots);a.add("cursor",stack(p.containerMenu.getCarried()));
  var rays=new JsonArray();for(int deg:new int[]{-45,-40,-35,-30,-25,-20,-15,-10,-5,0,5,10,15,20,25,30,35,40,45}){double rad=Math.toRadians(p.getYRot()+deg);var eye=p.getEyePosition();var end=eye.add(-Math.sin(rad)*12,-.5,Math.cos(rad)*12);var hit=m.level.clip(new ClipContext(eye,end,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p));var ray=object("block",hit.getType()==HitResult.Type.MISS?"minecraft:air":BuiltInRegistries.BLOCK.getKey(m.level.getBlockState(hit.getBlockPos()).getBlock()).toString());ray.addProperty("offset",deg);ray.addProperty("distance",eye.distanceTo(hit.getLocation()));rays.add(ray);}a.add("rays",rays);
  // Demonstrator-only visible hits. Never supplied to the learned policy.
  var mining=new JsonArray();var eye=p.getEyePosition();
  for(int dy:new int[]{-30,-20,-10,0,10,20,30})for(int dx:new int[]{-40,-30,-20,-10,0,10,20,30,40}){
   double yr=Math.toRadians(p.getYRot()+dx),pr=Math.toRadians(p.getXRot()+dy);
   var end=eye.add(-Math.sin(yr)*Math.cos(pr)*12,-Math.sin(pr)*12,Math.cos(yr)*Math.cos(pr)*12);
   var hit=m.level.clip(new ClipContext(eye,end,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p));
   if(hit.getType()!=HitResult.Type.MISS && m.level.getBlockState(hit.getBlockPos()).is(Blocks.OAK_LOG)){
    var bp=hit.getBlockPos();var q=new JsonObject();q.addProperty("x",bp.getX()+.5);q.addProperty("y",bp.getY()+.5);q.addProperty("z",bp.getZ()+.5);mining.add(q);
   }
  }
  a.add("visible_logs",mining);
  var cross=p.pick(4.5,0,false);a.addProperty("crosshair_log",cross instanceof BlockHitResult bh && cross.getType()!=HitResult.Type.MISS && m.level.getBlockState(bh.getBlockPos()).is(Blocks.OAK_LOG));
  var f=frame;if(f!=null){a.addProperty("rgb",f.rgb);a.addProperty("frame",f.number);a.addProperty("frame_tick",f.tick);a.addProperty("frame_age_ms",(System.nanoTime()-f.nano)/1e6);a.addProperty("width",64);a.addProperty("height",36);}j.add("agent",a);
  var t=new JsonObject();var l=lab;if(l!=null){double d=Math.hypot(p.getX()-l.x,p.getZ()-l.z);t.addProperty("distance",d);t.addProperty("scenario",l.scenario);t.addProperty("goal",l.goal);int logs=0;for(int i=0;i<p.getInventory().getContainerSize();i++){var item=p.getInventory().getItem(i);if(item.is(net.minecraft.world.item.Items.OAK_LOG))logs+=item.getCount();}
   int remainingLogs=0;for(int y=200;y<=201;y++)if(m.level.getBlockState(new BlockPos((int)Math.floor(l.x),y,(int)Math.floor(l.z))).is(Blocks.OAK_LOG))remainingLogs++;
   t.addProperty("collected",logs);t.addProperty("remaining_logs",remainingLogs);t.addProperty("stage",l.stage);
   t.addProperty("success",l.stage>=4?logs>=1:d<1.35);t.addProperty("dead",!p.isAlive());t.addProperty("server_ticks",m.getSingleplayerServer().getTickCount()-l.start);}j.add("trainer",t);return j;
 }
 static void inventory(JsonObject b){var m=mc();String op=b.get("op").getAsString();if(op.equals("open")){release("Manual inventory");m.gui.setScreen(new InventoryScreen(m.player));return;}if(op.equals("close")){m.player.closeContainer();m.gui.setScreen(null);return;}if(!op.equals("click"))throw new IllegalArgumentException("Unknown inventory operation");int id=b.get("container_id").getAsInt(),slot=b.get("slot").getAsInt(),button=b.get("button").getAsInt();String mode=b.has("mode")?b.get("mode").getAsString():"PICKUP";if(id!=m.player.containerMenu.containerId||slot<0||slot>=m.player.containerMenu.slots.size()||button<0||button>1||!Set.of("PICKUP","QUICK_MOVE").contains(mode))throw new IllegalArgumentException("Invalid/stale container action");m.gameMode.handleContainerInput(id,slot,button,ContainerInput.valueOf(mode),m.player);}
 static long mixSeed(long z){z=(z^(z>>>30))*0xbf58476d1ce4e5b9L;z=(z^(z>>>27))*0x94d049bb133111ebL;return z^(z>>>31);}
 static void reset(JsonObject b,CompletableFuture<JsonObject> f,long epoch){
  release("Reset");stopped=false;if(!mc().player.isAlive())throw new IllegalStateException("Manual respawn required in 0.1.1");int stage=b.has("stage")?b.get("stage").getAsInt():3;if(stage<0||stage>6)throw new IllegalArgumentException("Invalid curriculum stage");long scenario=b.get("scenario").getAsLong();if(scenario<0)throw new IllegalArgumentException("Invalid scenario");String goal=b.has("goal")?b.get("goal").getAsString():"gold_block";int goalIndex=Arrays.asList(GOALS).indexOf(goal);if(goalIndex<0)throw new IllegalArgumentException("Unsupported goal");if(stage>=4&&!goal.equals("oak_log"))throw new IllegalArgumentException("Mining task requires oak_log");var s=mc().getSingleplayerServer();var uuid=mc().player.getUUID();
  s.execute(()->{try{
   if(epoch!=EPOCH.get())throw new IllegalStateException("Cancelled reset");var p=s.getPlayerList().getPlayer(uuid);if(p==null)throw new IllegalStateException("Player left");var level=s.overworld();var rng=new Random(mixSeed(scenario));
   double angle=rng.nextDouble()*Math.PI*2;double sx=.5,sz=.5;
   int[] txs=new int[4],tzs=new int[4];var order=new ArrayList<Integer>(List.of(0,1,2,3));Collections.shuffle(order,rng);
   for(int i=0;i<4;i++){
    double theta=angle+Math.toRadians(stage<=1?-36+i*24:i*90);
    double radius=stage==0?4.5:6.5;
    txs[order.get(i)]=(int)Math.round(Math.sin(theta)*radius);tzs[order.get(i)]=(int)Math.round(Math.cos(theta)*radius);
   }
   if(stage==3){sx=rng.nextInt(3)-.5;sz=rng.nextInt(3)-.5;}
   if(stage>=4){
    
    double radius=stage==4?2.4:stage==5?5.0:6.5;
    txs[3]=(int)Math.round(Math.sin(angle)*radius);tzs[3]=(int)Math.round(Math.cos(angle)*radius);
   }
   if(stage==6){
    for(int i=0;i<4;i++){double theta=angle+Math.toRadians(-36+i*24);txs[order.get(i)]=(int)Math.round(Math.sin(theta)*6.5);tzs[order.get(i)]=(int)Math.round(Math.cos(theta)*6.5);}
   }
   int tx=txs[goalIndex],tz=tzs[goalIndex];
   // Stage 1 is independent of the requested target: identical world/view for paired goal tests.
   float yaw=(float)(Math.toDegrees(-angle)+(stage<=1||stage>=4?(rng.nextDouble()*(stage==6?80:30)-(stage==6?40:15)):rng.nextDouble()*360));
   s.setDifficulty(Difficulty.NORMAL,true);
   for(int x=-10;x<=10;x++)for(int z=-10;z<=10;z++)for(int y=199;y<=205;y++)level.setBlockAndUpdate(new BlockPos(x,y,z),(y==199?Blocks.STONE:y==205||Math.abs(x)==10||Math.abs(z)==10?Blocks.GLASS:Blocks.AIR).defaultBlockState());
   for(int i=0;i<4;i++){if((stage==0||stage==4||stage==5)&&i!=goalIndex)continue;level.setBlockAndUpdate(new BlockPos(txs[i],200,tzs[i]),TARGETS[i].defaultBlockState());
    if(stage<4||i!=goalIndex||scenario%2==0)level.setBlockAndUpdate(new BlockPos(txs[i],201,tzs[i]),TARGETS[i].defaultBlockState());}
   for(String cmd:List.of("time set day","weather clear","kill @e[type=!minecraft:player,x=-10,y=199,z=-10,dx=20,dy=6,dz=20]"))s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),cmd);
   p.setGameMode(GameType.SURVIVAL);p.getInventory().clearContent();p.removeAllEffects();p.setHealth(p.getMaxHealth());p.getFoodData().setFoodLevel(20);p.getFoodData().setSaturation(5);p.setDeltaMovement(Vec3.ZERO);p.teleportTo(level,sx,200,sz,Set.of(),yaw,stage>=4?(float)(rng.nextDouble()*20-10):0,true);
   var next=new Lab(scenario,tx+.5,tz+.5,s.getTickCount(),goal,stage);
   QUEUE.add(()->{if(epoch!=EPOCH.get()){f.completeExceptionally(new IllegalStateException("Cancelled reset"));return;}lab=next;frame=null;mc().gui.setScreen(null);acquire();remaining=12;current=new Action();pending=f;});
  }catch(Throwable ex){f.completeExceptionally(ex);}});
 }
 public static void shutdown(){if(http!=null)http.stop(0);if(workers!=null)workers.shutdownNow();}
}
