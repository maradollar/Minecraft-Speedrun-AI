package de.msai;
import net.minecraft.client.player.ClientInput;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;
public class AgentInput extends ClientInput {
 public void tick(){var a=Bridge.action();keyPresses=new Input(a.forward,a.back,a.left,a.right,a.jump,a.sneak,a.sprint);moveVector=new Vec2((a.left?1:0)-(a.right?1:0),(a.forward?1:0)-(a.back?1:0)).normalized();}
}
