package de.msai.mixin;
import de.msai.Bridge;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=GameRenderer.class,remap=false)
public class RenderMixin {
 @Inject(method="render",at=@At("RETURN")) private void frame(CallbackInfo ci){Bridge.capture();}
}
