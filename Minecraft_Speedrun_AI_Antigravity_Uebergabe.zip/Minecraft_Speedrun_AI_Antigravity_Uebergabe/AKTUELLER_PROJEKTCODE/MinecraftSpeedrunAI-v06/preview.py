"""Read-copy-close before display to avoid Windows file locks."""
import tkinter as tk
from pathlib import Path
import numpy as np
from PIL import Image,ImageTk
root=tk.Tk();root.title('MSAI v06 - actual model frames')
label=tk.Label(root);label.pack();text=tk.Label(root,text='Waiting for training...');text.pack()
def tick():
    candidates=list(Path('runs-v06').glob('stage*/preview.npz'))
    if candidates:
        try:
            p=max(candidates,key=lambda p:p.stat().st_mtime_ns)
            with np.load(p,allow_pickle=False) as f:frame=f['frames'][:,:,3:].copy();action=str(f['action']);probs=f['probabilities'].copy()
            image=ImageTk.PhotoImage(Image.fromarray(frame).resize((768,432),Image.Resampling.NEAREST))
            label.configure(image=image);label.image=image;text.configure(text=action+' | '+np.array2string(probs,precision=2))
        except (OSError,ValueError,KeyError,EOFError):pass
    root.after(150,tick)
tick();root.mainloop()
