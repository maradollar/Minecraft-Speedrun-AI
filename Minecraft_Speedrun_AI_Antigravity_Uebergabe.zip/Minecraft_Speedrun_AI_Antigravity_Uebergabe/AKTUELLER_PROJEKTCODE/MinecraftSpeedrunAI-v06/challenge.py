"""Resume-safe curriculum, immutable navigation baseline and held-out evaluation."""
import argparse,json,os,subprocess,sys
from pathlib import Path
from msai6.core import Learner

def promotion(student,blind,random):
    return (all(s['completed']==12 and not s['interrupted'] for s in (student,blind,random))
            and student['successes']>=10 and student['successes']-max(blind['successes'],random['successes'])>=3)

def run(stage,mode,game,policy='student',episodes=12,start=600000):
    folder=Path('runs-v06')/f'stage{stage}'
    subprocess.run([sys.executable,'-m','msai6.run',mode,'--stage',str(stage),'--game-dir',game,'--episodes',str(episodes),'--policy',policy,'--start',str(start),'--output',str(folder)],check=True)
    latest=max(folder.glob(f'{mode}-{policy}-stage{stage}-*/summary.json'),key=lambda p:p.stat().st_mtime_ns)
    return json.loads(latest.read_text())

def main():
    p=argparse.ArgumentParser();p.add_argument('--game-dir',default=r'C:\MC-AI\instance1');a=p.parse_args()
    root=Path('runs-v06');root.mkdir(exist_ok=True)
    with (root/'pipeline.lock').open('a+b') as lock:
        lock.seek(0,2)
        if lock.tell()==0:lock.write(b'0');lock.flush()
        lock.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        report_path=root/'result.json';report=json.loads(report_path.read_text()) if report_path.exists() else {}
        for stage in (4,5,6):
            if report.get(str(stage),{}).get('passed'):continue
            print(f'STAGE {stage}: teacher environment check',flush=True)
            teacher=run(stage,'evaluate',a.game_dir,'teacher',4,500000+stage*1000)
            if teacher['completed']!=4 or teacher['successes']!=4:
                report[str(stage)]=dict(passed=False,teacher=teacher,reason='teacher_gate_failed')
                report_path.write_text(json.dumps(report,indent=2));print('STOP: teacher failed. Send runs-v06; no training wasted.');return
            ck=root/'resource.npz';count=0
            if ck.exists():count=Learner.load(ck)[1]['stage_episodes'].get(str(stage),0)
            remaining=max(0,40-count)
            if remaining:run(stage,'learn',a.game_dir,episodes=remaining)
            # Different worlds from teacher gate and all training (training seeds <100000).
            start=600000+stage*1000
            student=run(stage,'evaluate',a.game_dir,start=start)
            blind=run(stage,'evaluate',a.game_dir,'blind',start=start)
            random=run(stage,'evaluate',a.game_dir,'random',start=start)
            passed=promotion(student,blind,random)
            retention={}
            if passed:
                for earlier in range(4,stage):
                    check=run(earlier,'evaluate',a.game_dir,start=650000+earlier*1000)
                    retention[str(earlier)]=check
                    passed=passed and check['completed']==12 and check['successes']>=10 and not check['interrupted']
            report[str(stage)]=dict(passed=passed,teacher=teacher,student=student,blind=blind,random=random,retention=retention)
            report_path.write_text(json.dumps(report,indent=2))
            if not passed:
                print('STOP: skill gate not passed. Send runs-v06 for diagnosis. Existing progress saved.');return
            import shutil
            shutil.copy2(ck,root/f'passed-stage{stage}.npz')
            print(f'STAGE {stage} PASSED. Advancing to harder task.',flush=True)
        print('All lab challenges passed. Send runs-v06; natural-world wood/crafting remains next.',flush=True)
if __name__=='__main__':main()
