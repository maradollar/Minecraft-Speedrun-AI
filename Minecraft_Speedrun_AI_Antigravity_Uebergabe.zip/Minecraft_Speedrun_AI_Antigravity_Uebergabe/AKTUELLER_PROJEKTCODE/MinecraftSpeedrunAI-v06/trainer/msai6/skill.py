"""Image-only resource skill. No world state or teacher access."""
import numpy as np
from msai5.core import Learner as NavigationModel, PIXELS, TAIL as OLD_TAIL
from .core import Learner,VisionHistory,SCHEMA,TAIL,ACTIONS,TICKS,NAMES

def transfer(path):
    old,meta=NavigationModel.load(path)
    if not meta.get('schema','').startswith('v05-'):raise ValueError('Expected v05 navigation')
    model=Learner(hidden=old.hidden,lr=.0003)
    for k in ('wc','bc','b1','wv','bv'):model.p[k]=old.p[k].copy()
    n=old.p['w1'].shape[0]-OLD_TAIL
    model.p['w1'][:n+3]=old.p['w1'][:n+3]
    model.p['w1'][n+3:n+7]=0
    model.p['w1'][n+7:]=old.p['w1'][n+3:]
    model.p['wp'][:,:3]=old.p['wp'];model.p['bp'][:3]=old.p['bp']
    return model,dict(schema=SCHEMA,episodes=0,source_hash=old.digest(),stage_episodes={})

class ResourceSkill:
    def __init__(self,model):self.model=model;self.reset()
    def reset(self):self.history=VisionHistory();self.last=None
    def observe(self,rgb):return self.history.encode(rgb,'oak_log',self.last)
    def decide(self,rgb):
        _,p,_=self.model.forward(self.observe(rgb));a=int(p[0].argmax());self.executed(a)
        return dict(action=dict(ACTIONS[a]),ticks=TICKS[a],name=NAMES[a],probabilities=p[0].tolist())
    def executed(self,a):self.last=int(a)
