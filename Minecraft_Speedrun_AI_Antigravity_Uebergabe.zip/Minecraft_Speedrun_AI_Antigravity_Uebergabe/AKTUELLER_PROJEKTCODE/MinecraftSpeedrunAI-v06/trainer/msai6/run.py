import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,base64,json,time,signal
from pathlib import Path
import numpy as np
from msai.env import Client,LabEnv
from msai5.run import log
from msai5.preview_io import publish
from .core import Learner,DIM,PIXELS,SCHEMA,ACTIONS,TICKS,NAMES
from .skill import ResourceSkill,transfer

def policy_action(model,x):
    _,p,_=model.forward(x);return int(p[0].argmax()),p[0]

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['learn','evaluate'])
    p.add_argument('--game-dir',default=r'C:\MC-AI\instance1');p.add_argument('--episodes',type=int,default=40)
    p.add_argument('--stage',type=int,choices=[4,5,6],default=4)
    p.add_argument('--policy',choices=['student','teacher','random','blind'],default='student')
    p.add_argument('--start',type=int,default=600000);p.add_argument('--output',default='runs-v06')
    p.add_argument('--checkpoint',default='runs-v06/resource.npz');a=p.parse_args(argv)
    if a.episodes<1 or a.start<100000:p.error('Invalid episode count/test range')
    training=a.mode=='learn'
    if training and a.policy!='student':p.error('Use student for learning')
    ck=Path(a.checkpoint);ck.parent.mkdir(parents=True,exist_ok=True)
    if ck.exists():model,meta=Learner.load(ck)
    elif training or a.policy in ('teacher','random'):model,meta=transfer('seed/navigation-v052.npz')
    else:raise FileNotFoundError('Run training first')
    if meta['schema']!=SCHEMA:raise ValueError('Wrong checkpoint')
    initial=model.digest();rng=np.random.default_rng(617)
    if training and 'scenario_rng' in meta:rng.bit_generator.state=meta['scenario_rng']
    xs=[];ys=[];data=ck.with_name(ck.stem+'-replay.npz')
    if training and data.exists():
        with np.load(data,allow_pickle=False) as f:
            xs=list(np.concatenate([f['frames'].astype('f4')/255-.5,f['tail']],axis=1));ys=list(f['labels'])
    out=Path(a.output)/f'{a.mode}-{a.policy}-stage{a.stage}-{time.time_ns()}';out.mkdir(parents=True)
    (out/'manifest.json').write_text(json.dumps(dict(**vars(a),schema=SCHEMA,initial_hash=initial,source_hash=meta['source_hash']),indent=2))
    client=Client(a.game_dir);fresh=LabEnv(a.game_dir,'resource');skill=ResourceSkill(model)
    if client.call('/health').get('version')!='0.6.0':raise RuntimeError('Install 0.6.0 JAR first (Minecraft closed).')
    stopping=False;completed=successes=0;started=time.monotonic()
    def stop(*_):
        nonlocal stopping
        stopping=True;print('Stopping after current action; saving...',flush=True)
    signal.signal(signal.SIGINT,stop)
    def save():
        if not training:return
        meta['scenario_rng']=rng.bit_generator.state
        xx=np.asarray(xs,'f4').reshape(-1,DIM)
        with data.with_suffix('.tmp').open('wb') as f:
            np.savez_compressed(f,frames=np.rint((xx[:,:PIXELS]+.5)*255).clip(0,255).astype('u1'),tail=xx[:,PIXELS:],labels=np.asarray(ys,'i8'))
        os.replace(data.with_suffix('.tmp'),data);model.save(ck,meta)
    try:
        for ep in range(a.episodes):
            if stopping:break
            scenario=int(rng.integers(100000)) if training else a.start+ep
            fresh.last_frame=-1;raw=fresh.fresh(client.call('/reset',dict(stage=a.stage,goal='oak_log',scenario=scenario)))
            skill.reset();teacher=None
            if training or a.policy=='teacher':
                from .teacher import Teacher
                teacher=Teacher()
            t0=time.monotonic();assisted=0;reason='timeout';turns=0;previous=None
            stage_count=meta['stage_episodes'].get(str(a.stage),0)
            mix=1. if stage_count<12 else max(.35,1-(stage_count-12)/35)
            for step in range(200):
                if stopping:reason='interrupted';break
                rgb=base64.b64encode(bytes(64*36*3)).decode() if a.policy=='blind' else raw['agent']['rgb']
                x=skill.observe(rgb);chosen,probs=policy_action(model,x)
                label=teacher.label(raw['agent']) if teacher else None
                use_teacher=a.policy=='teacher' or (training and rng.random()<mix)
                if training:xs.append(x);ys.append(label);xs=xs[-3500:];ys=ys[-3500:]
                action=label if use_teacher else int(rng.integers(7)) if a.policy=='random' else chosen
                assisted+=int(use_teacher);turns+=int({previous,action}=={1,2});previous=action
                publish(Path(a.output)/'preview.npz',frames=np.rint((x[:PIXELS].reshape(36,64,6)+.5)*255).clip(0,255).astype('u1'),probabilities=probs,goal=np.array('oak_log'),action=np.array(NAMES[action]))
                raw=fresh.fresh(client.call('/step',dict(action=ACTIONS[action],ticks=TICKS[action])))
                skill.executed(action);t=raw['trainer']
                log(out/'actions.csv',dict(episode=ep+1,scenario=scenario,step=step+1,action=NAMES[action],teacher_used=use_teacher,probabilities=json.dumps(probs.tolist()),collected=t['collected'],remaining_logs=t['remaining_logs'],distance=t['distance']))
                if t['success'] or t['dead'] or time.monotonic()-t0>90:
                    reason='success' if t['success'] else 'death' if t['dead'] else 'timeout';break
            client.stop()
            if reason=='interrupted':break
            completed+=1;successes+=int(reason=='success')
            if training:
                model.lr=.0003;metrics=model.imitate(np.stack(xs),np.array(ys),batches=40)
                meta['episodes']+=1;meta['stage_episodes'][str(a.stage)]=stage_count+1
                log(out/'updates.csv',dict(episode=meta['episodes'],**metrics));save()
            log(out/'episodes.csv',dict(episode=ep+1,scenario=scenario,stage=a.stage,success=reason=='success',reason=reason,collected=t['collected'],remaining_logs=t['remaining_logs'],steps=step+1,teacher_actions=assisted,reversals=turns,seconds=time.monotonic()-t0))
            eta=(time.monotonic()-started)/completed*(a.episodes-completed)/60
            print(f'{ep+1}/{a.episodes} stage {a.stage}: {reason}; wood={t["collected"]}; teacher={assisted}; remaining ~{eta:.1f} min',flush=True)
    finally:
        try:save()
        finally:client.stop()
        summary=dict(completed=completed,successes=successes,stage=a.stage,policy=a.policy,interrupted=stopping,initial_hash=initial,final_hash=model.digest(),seconds=time.monotonic()-started)
        (out/'summary.json').write_text(json.dumps(summary,indent=2))
    if not training and initial!=model.digest():raise AssertionError('Evaluation changed model')
    print(f'SAVED {out}: {successes}/{completed}',flush=True)
    if stopping:raise SystemExit(130)
if __name__=='__main__':main()
