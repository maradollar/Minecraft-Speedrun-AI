"""Demonstrator only: geometric labels from visible log hits, never student inputs."""
import math
class Teacher:
    def __init__(self):self.target=None
    def label(self,a):
        hits=a['visible_logs']
        if hits:
            self.target=min(hits,key=lambda b:(b['x']-a['x'])**2+(b['y']-a['y']-1.62)**2+(b['z']-a['z'])**2)
        if self.target is None:return 2
        b=self.target;dx=b['x']-a['x'];dz=b['z']-a['z'];distance=math.hypot(dx,dz)
        yaw=math.degrees(math.atan2(-dx,dz));error=(yaw-a['yaw']+180)%360-180
        if abs(error)>3:return 1 if error<0 else 2
        if not hits:return 0  # walk to last visibly observed block to collect its drop
        pitch=math.degrees(math.atan2(a['y']+1.62-b['y'],max(.01,distance)))
        delta=pitch-a['pitch']
        if abs(delta)>3:return 3 if delta<0 else 4
        # Move close enough for item collection BEFORE breaking; avoids hitting the floor.
        if distance>1.65:return 0
        if a['crosshair_log']:return 5
        return 4 if delta>=0 else 3
