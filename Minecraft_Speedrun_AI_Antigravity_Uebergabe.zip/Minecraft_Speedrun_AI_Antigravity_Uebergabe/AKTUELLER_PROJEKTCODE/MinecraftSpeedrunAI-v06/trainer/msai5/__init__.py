"""Reusable goal-conditioned visual navigation skill."""
