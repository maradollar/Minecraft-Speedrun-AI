"""Demonstration labels ONLY; student does not import this module."""
import math
import numpy as np

def label(agent,goal):
    rays=[r for r in agent['rays'] if r['block']=='minecraft:'+goal]
    if not rays:return 2
    offsets=[float(r['offset']) for r in rays]
    angle=float(np.mean(offsets))
    return 0 if abs(angle)<=7 else 1 if angle<0 else 2
