"""Public reusable skill API. No reset, world coordinate or teacher access here."""
from dataclasses import dataclass
import numpy as np
from .core import Learner,VisionHistory,SCHEMA,ACTIONS

@dataclass(frozen=True)
class SkillDecision:
    action: dict
    probabilities: tuple
    status: str = 'running'

class NavigationSkill:
    name='navigate_to_block'
    def __init__(self,model):
        self.model=model;self.history=VisionHistory();self.goal=None;self.last_action=None
    @classmethod
    def load(cls,path):
        model,meta=Learner.load(path)
        if meta.get('schema')!=SCHEMA:raise ValueError('Incompatible skill checkpoint')
        return cls(model)
    def reset(self,goal):
        self.goal=goal;self.history=VisionHistory();self.last_action=None
    def observe(self,rgb):
        if self.goal is None:raise RuntimeError('Call reset(goal) first')
        return self.history.encode(rgb,self.goal,self.last_action)
    def decide(self,rgb):
        x=self.observe(rgb);_,p,_=self.model.forward(x);a=int(p[0].argmax())
        self.last_action=a
        return SkillDecision(dict(ACTIONS[a]),tuple(map(float,p[0])))
    def executed(self,action):
        self.last_action=int(action)
