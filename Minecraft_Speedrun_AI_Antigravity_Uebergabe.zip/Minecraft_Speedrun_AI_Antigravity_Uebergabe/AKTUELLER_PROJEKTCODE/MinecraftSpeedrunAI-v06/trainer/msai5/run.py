import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,csv,json,signal,time,base64
from pathlib import Path
import numpy as np
from msai.env import Client,LabEnv
from msai2.core import reward,gae
from .core import Learner,DIM,SCHEMA,ACTIONS,NAMES,GOALS,GOAL_DIM,SLOTS,PIXELS,TAIL
from .skill import NavigationSkill
from .teacher import label
from .preview_io import publish

def log(path,row):
    exists=path.exists()
    with path.open('a',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,list(row))
        if not exists:w.writeheader()
        w.writerow(row)

def replay_save(path,xs,ys):
    x=np.asarray(xs,'f4').reshape(-1,DIM)
    with path.with_suffix('.tmp').open('wb') as f:
        np.savez_compressed(f,frames=np.rint((x[:,:PIXELS]+.5)*255).clip(0,255).astype('u1'),tail=x[:,PIXELS:],y=np.asarray(ys,'i8'))
        f.flush();os.fsync(f.fileno())
    os.replace(path.with_suffix('.tmp'),path)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('mode',choices=['learn','evaluate','reinforce'])
    p.add_argument('--game-dir',default=r'C:\MC-AI\instance1')
    p.add_argument('--checkpoint',default='runs-v05/latest.npz')
    p.add_argument('--output',default='runs-v05')
    p.add_argument('--episodes',type=int,default=40)
    p.add_argument('--stage',type=int,choices=range(4),default=1)
    p.add_argument('--goal',choices=GOALS+('cycle',),default='cycle')
    p.add_argument('--policy',choices=['student','teacher','random'],default='student')
    p.add_argument('--test-start',type=int,default=200000)
    p.add_argument('--seed',type=int,default=51)
    p.add_argument('--blank-images',action='store_true')
    p.add_argument('--focus-goal',choices=GOALS)
    p.add_argument('--teacher-floor',type=float,default=.2)
    p.add_argument('--learn-rate',type=float,default=.001)
    a=p.parse_args();training=a.mode!='evaluate'
    if not 0<=a.teacher_floor<=1 or not 0<a.learn_rate<=.01:p.error('Invalid teacher floor or learning rate')
    if a.episodes<1 or a.test_start<100000:p.error('Invalid episodes/test range')
    if a.blank_images and (training or a.policy!='student'):p.error('Blind images only for student evaluation')
    ck=Path(a.checkpoint);data=ck.with_name(ck.stem+'-demonstrations.npz')
    meta=dict(schema=SCHEMA,episodes=0,learn_episodes=0,goals=list(GOALS),goal_slots=SLOTS)
    rng=np.random.default_rng(a.seed)
    if ck.exists():
        model,meta=Learner.load(ck)
        if meta.get('schema')!=SCHEMA:raise ValueError('Checkpoint is not a v05 goal-conditioned image model')
        if any(SLOTS.get(g)!=slot for g,slot in meta.get('goal_slots',{}).items()):raise ValueError('Existing goal slots must not be changed')
        if training and 'scenario_rng' in meta:rng.bit_generator.state=meta['scenario_rng']
    elif a.mode=='reinforce' or (not training and a.policy=='student'):
        raise FileNotFoundError('First run 02_LERNEN.cmd')
    else:model=Learner()
    skill=NavigationSkill(model);xs=[];ys=[]
    if a.mode=='learn' and data.exists():
        with np.load(data,allow_pickle=False) as d:
            x=np.concatenate([d['frames'].astype('f4')/255-.5,d['tail']],axis=1)
            if x.shape[1]!=DIM or len(x)!=len(d['y']):raise ValueError('Invalid demonstration data')
            xs,ys=list(x),list(d['y'])
    out=Path(a.output)/f'{a.mode}-{a.policy}-{time.time_ns()}';out.mkdir(parents=True)
    initial=model.digest();start_all=time.monotonic()
    (out/'manifest.json').write_text(json.dumps(dict(**vars(a),schema=SCHEMA,initial_hash=initial),indent=2))
    client=Client(a.game_dir);fresh=LabEnv(a.game_dir,'instance-1')
    if client.call('/health').get('version') not in ('0.5.0','0.6.0'):raise RuntimeError('Install the included msai-0.5.0-mc26.3.jar with 00_INSTALLIEREN.cmd while Minecraft is closed.')
    stopping=False
    def stop(*_):
        nonlocal stopping
        stopping=True;print('Stopping; saving and releasing controls...',flush=True)
    signal.signal(signal.SIGINT,stop)
    def save():
        if training:
            ck.parent.mkdir(parents=True,exist_ok=True);meta['scenario_rng']=rng.bit_generator.state
            if a.mode=='learn':replay_save(data,xs,ys)
            model.save(ck,meta)
    successes=completed=0;goal_stats={g:[0,0] for g in GOALS}
    if training and not ck.exists():save()
    try:
        for ep in range(a.episodes):
            if stopping:break
            episode_start=time.monotonic()
            goal=GOALS[(meta['episodes'] if training else ep)%len(GOALS)] if a.goal=='cycle' else a.goal
            if a.mode=='learn' and a.focus_goal and a.goal=='cycle':
                others=[g for g in GOALS if g!=a.focus_goal]
                turn=meta['episodes']
                goal=a.focus_goal if turn%2==0 else others[(turn//2)%len(others)]
            scenario=int(rng.integers(100000)) if training else a.test_start+(ep//len(GOALS) if a.goal=='cycle' else ep)
            fresh.last_frame=-1
            raw=fresh.fresh(client.call('/reset',dict(scenario=scenario,stage=a.stage,goal=goal)))
            skill.reset(goal)
            def observe():
                rgb=base64.b64encode(bytes(36*64*3)).decode() if a.blank_images else raw['agent']['rgb']
                return skill.observe(rgb)
            x=observe();tick0=raw['trainer']['server_ticks'];play_start=time.monotonic()
            trajectory=[];assisted=0;score=0.;reason='interrupted'
            prior=meta.get('learn_episodes',0);mix=1. if prior<12 else max(a.teacher_floor,1-(prior-12)/24)
            for step in range(180):
                if stopping:break
                _,probs,values=model.forward(x);probs=probs[0]
                teacher_action=label(raw['agent'],goal) if a.mode=='learn' or a.policy=='teacher' else None
                if a.mode=='learn':
                    # Counterfactual labels: same image, alternative requested block.
                    # Only the requested goal is supplied to the learned policy.
                    for g in GOALS:
                        example=x.copy();example[-GOAL_DIM:]=0;example[-GOAL_DIM+SLOTS[g]]=2
                        xs.append(example);ys.append(label(raw['agent'],g))
                    use_teacher=bool(rng.random()<mix);action=teacher_action if use_teacher else int(probs.argmax())
                elif a.mode=='reinforce':
                    action=int(model.rng.choice(3,p=probs.astype('f8')/probs.sum(dtype='f8')));use_teacher=False
                elif a.policy=='teacher':action=teacher_action;use_teacher=True
                elif a.policy=='random':action=int(rng.integers(3));use_teacher=False
                else:action=int(probs.argmax());use_teacher=False
                assisted+=int(use_teacher)
                preview=Path(a.output)/'preview.npz'
                publish(preview,frames=np.rint((x[:PIXELS].reshape(36,64,6)+.5)*255).clip(0,255).astype('u1'),probabilities=probs,previous_action=x[PIXELS:PIXELS+3],goal=np.array(goal))
                old=raw['trainer']['distance'];before=x.copy()
                raw=fresh.fresh(client.call('/step',dict(action=ACTIONS[action],ticks=2)))
                skill.executed(action);x=observe();t=raw['trainer']
                done=bool(t['success'] or t['dead'] or step==179 or time.monotonic()-play_start>=90)
                r=reward(old,t['distance'],t['success'],t['dead'],done);score+=r
                if a.mode=='reinforce':trajectory.append((before,action,r,float(values[0]),done,float(np.log(probs[action]+1e-9))))
                log(out/'actions.csv',dict(episode=ep+1,scenario=scenario,goal=goal,step=step+1,action=NAMES[action],teacher_used=use_teacher,probabilities=json.dumps(probs.tolist()),distance_before=old,distance_after=t['distance'],reward=r,frame=raw['agent']['frame'],frame_age_ms=raw['agent']['frame_age_ms']))
                if done:
                    reason='success' if t['success'] else 'death' if t['dead'] else 'timeout';break
            client.stop()
            if reason=='interrupted':break
            play_seconds=time.monotonic()-play_start
            completed+=1;successes+=int(reason=='success');goal_stats[goal][0]+=int(reason=='success');goal_stats[goal][1]+=1
            update_start=time.monotonic()
            if training:
                meta['episodes']+=1
                if a.mode=='learn':
                    meta['learn_episodes']=prior+1
                    # Keep previous goals in replay; four labels are generated per image.
                    xs,ys=xs[-4000:],ys[-4000:];model.lr=a.learn_rate
                    metrics=model.imitate(np.asarray(xs),np.asarray(ys),batches=45,focus_goal=a.focus_goal)
                else:
                    xx,aa,rr,vv,dd,ll=zip(*trajectory);adv,ret=gae(rr,vv,dd,0);model.lr=.0001
                    metrics=model.optimize(np.stack(xx),np.array(aa),ret,adv,np.array(ll))
                log(out/'updates.csv',dict(episode=meta['episodes'],**metrics));save()
            block_seconds=time.monotonic()-episode_start
            log(out/'episodes.csv',dict(episode=ep+1,total_training_episodes=meta['episodes'],goal=goal,scenario=scenario,stage=a.stage,success=reason=='success',reason=reason,steps=step+1,simulation_seconds=(t['server_ticks']-tick0)/20,play_seconds=play_seconds,update_save_seconds=time.monotonic()-update_start,total_seconds=block_seconds,assisted_actions=assisted,reward=score,model_hash=model.digest()))
            eta=(time.monotonic()-start_all)/completed*(a.episodes-completed)
            print(f'{ep+1}/{a.episodes} {goal}: {reason}; teacher={assisted}; updates={model.updates}; remaining estimate={eta/60:.1f} min',flush=True)
        if not training and model.digest()!=initial:raise AssertionError('Evaluation modified parameters')
    finally:
        try:save()
        finally:client.stop()
    elapsed=time.monotonic()-start_all
    summary=dict(mode=a.mode,policy=a.policy,stage=a.stage,completed=completed,successes=successes,goals=goal_stats,elapsed_seconds=elapsed,mean_episode_seconds=elapsed/max(1,completed),initial_hash=initial,final_hash=model.digest(),interrupted=stopping)
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    print(f'SAVED {successes}/{completed}; {out}',flush=True)
    if stopping:raise SystemExit(130)
if __name__=='__main__':main()
