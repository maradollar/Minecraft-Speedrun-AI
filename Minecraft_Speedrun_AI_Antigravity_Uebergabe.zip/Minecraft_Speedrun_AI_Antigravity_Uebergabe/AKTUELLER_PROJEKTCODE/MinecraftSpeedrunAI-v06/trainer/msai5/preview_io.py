"""Best-effort preview publishing. Preview failures must never stop control/training."""
import io
import os
from pathlib import Path
import numpy as np

_warned = False

def publish(path, **arrays):
    global _warned
    path = Path(path)
    temp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    try:
        with temp.open('wb') as f:
            np.savez(f, **arrays)
        os.replace(temp, path)
        _warned = False
        return True
    except OSError as exc:
        # Windows can refuse replacement while a viewer/virus scanner holds
        # the previous file open. Keep the previous complete image and continue.
        if not _warned:
            print(f'Preview update skipped ({type(exc).__name__}). Training continues; model input is unaffected.', flush=True)
            _warned = True
        return False
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass

def read(path):
    # Close the OS file handle before parsing the NPZ archive or rendering UI.
    payload = Path(path).read_bytes()
    with np.load(io.BytesIO(payload), allow_pickle=False) as data:
        return {key: data[key].copy() for key in data.files}
