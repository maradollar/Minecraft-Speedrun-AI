import base64, json
from pathlib import Path
CATALOG=json.loads((Path(__file__).resolve().parents[2]/"config/goals.json").read_text())
GOALS=tuple(g["id"] for g in CATALOG["goals"])
SLOTS={g["id"]:g["slot"] for g in CATALOG["goals"]}
GOAL_DIM=16
if len(SLOTS)!=len(GOALS) or len(set(SLOTS.values()))!=len(GOALS) or any(not isinstance(v,int) or v<0 or v>=GOAL_DIM for v in SLOTS.values()):
    raise ValueError("Invalid or duplicate goal slots")
TAIL=3+GOAL_DIM
PIXELS=36*64*6
import numpy as np
from msai.model import ActorCritic
from msai2.core import PPO

SCHEMA = 'v05-rgb64x36-history2-goal16-conv8-actions3'
DIM = PIXELS+TAIL
ACTIONS = [{'forward':True},{'yaw':-10},{'yaw':10}]
NAMES = ['forward','left','right']

def pixels(rgb):
    """No agent dictionary accepted: cannot consume rays, yaw or coordinates."""
    b=base64.b64decode(rgb,validate=True)
    if len(b)!=36*64*3: raise ValueError('Expected 64x36 RGB from the existing mod')
    return np.frombuffer(b,np.uint8).reshape(36,64,3).copy()

class VisionHistory:
    def __init__(self):self.previous=None
    def encode(self,rgb,goal,last_action=None):
        if goal not in SLOTS:raise ValueError("Unknown goal: "+goal)
        current=pixels(rgb)
        previous=current if self.previous is None else self.previous
        frames=np.concatenate([previous,current],axis=2).astype('f4')/255-.5
        action=np.zeros(3,'f4')
        if last_action is not None:action[last_action]=1
        self.previous=current
        goal_vector=np.zeros(GOAL_DIM,"f4");goal_vector[SLOTS[goal]]=2
        return np.concatenate([frames.ravel(),action,goal_vector])

class Learner(PPO):
    """One learned convolution, tanh hidden layer, policy/value heads; CPU NumPy.

    4x4, stride 4, no padding, 6 RGB-history channels -> 8 learned channels.
    No color threshold, hand-coded gold detector or target-bearing feature.
    """
    def __init__(self,inputs=DIM,actions=3,hidden=64,seed=31,lr=.001):
        if inputs!=DIM or actions!=3:raise ValueError('Wrong visual model shape')
        super().__init__(9*16*8+TAIL,actions,hidden,seed,lr)
        self.inputs=inputs
        self.p['wc']=(self.rng.standard_normal((96,8))/np.sqrt(96)).astype('f4')
        self.p['bc']=np.zeros(8,'f4')
        self.m['wc']=np.zeros_like(self.p['wc']);self.m['bc']=np.zeros(8,'f4')
        self.v['wc']=np.zeros_like(self.p['wc']);self.v['bc']=np.zeros(8,'f4')

    def features(self,x):
        x=np.atleast_2d(x).astype('f4')
        if x.shape[1]!=DIM or not np.isfinite(x).all():raise ValueError('Invalid visual input')
        frames=x[:,:PIXELS].reshape(-1,36,64,6)
        patches=np.concatenate([frames[:,dy:dy+36:4,dx:dx+64:4,:] for dy in range(4) for dx in range(4)],axis=3)
        conv=np.tanh(patches@self.p['wc']+self.p['bc'])
        features=np.concatenate([conv.reshape(len(x),-1),x[:,-TAIL:]],axis=1)
        return features,patches,conv

    def forward(self,x):
        features,_,_=self.features(x)
        return ActorCritic.forward(self,features)

    def backprop(self,x,h,dz,dv):
        features,patches,conv=self.features(x)
        dh=(dz@self.p['wp'].T+dv@self.p['wv'].T)*(1-h*h)
        df=dh@self.p['w1'].T
        dc=df[:,:-TAIL].reshape(conv.shape)*(1-conv*conv)
        return dict(w1=features.T@dh,b1=dh.sum(0),wp=h.T@dz,bp=dz.sum(0),
                    wv=h.T@dv,bv=dv.sum(0),
                    wc=patches.reshape(-1,96).T@dc.reshape(-1,8),bc=dc.sum((0,1,2)))

    def bc_objective(self,x,labels):
        h,p,_=self.forward(x);n=len(x)
        loss=-float(np.log(p[np.arange(n),labels]+1e-9).mean())
        dz=p.copy();dz[np.arange(n),labels]-=1;dz/=n
        return loss,self.backprop(x,h,dz,np.zeros((n,1),'f4'))

    def imitate(self,x,labels,batches=30,focus_goal=None):
        before=self.digest();labels=np.asarray(labels,int)
        goal_ids=x[:,-GOAL_DIM:].argmax(1)
        groups=[np.flatnonzero((labels==i)&(goal_ids==g)) for g in range(GOAL_DIM) for i in range(3)]
        groups=[g for g in groups if len(g)]
        if not groups:raise ValueError('No visual examples')
        probabilities=None
        if focus_goal is not None:
            focus_slot=SLOTS[focus_goal]
            is_focus=np.array([goal_ids[g[0]]==focus_slot for g in groups])
            if is_focus.any() and (~is_focus).any():
                probabilities=np.where(is_focus,.5/is_focus.sum(),.5/(~is_focus).sum())
        for _ in range(batches):
            selected=self.rng.integers(len(groups),size=32) if probabilities is None else self.rng.choice(len(groups),size=32,p=probabilities)
            ix=np.array([self.rng.choice(groups[k]) for k in selected])
            loss,g=self.bc_objective(x[ix],labels[ix])
            norm=np.sqrt(sum(float((v*v).sum()) for v in g.values()))
            if not np.isfinite(loss+norm):raise FloatingPointError('Nonfinite visual gradient')
            self.updates+=1
            for k in self.p:
                grad=g[k]*min(1.,1/(norm+1e-9))
                self.m[k]=.9*self.m[k]+.1*grad;self.v[k]=.999*self.v[k]+.001*grad*grad
                self.p[k]-=self.lr*(self.m[k]/(1-.9**self.updates))/(np.sqrt(self.v[k]/(1-.999**self.updates))+1e-8)
        return dict(loss=loss,changed=before!=self.digest(),updates=self.updates)

    def objective(self,x,a,returns,adv,oldlog):
        h,p,v=self.forward(x);n=len(x);log=np.log(p+1e-9)
        chosen=log[np.arange(n),a];ratio=np.exp(chosen-oldlog)
        clipped=np.clip(ratio,.8,1.2);sur=np.minimum(ratio*adv,clipped*adv)
        active=((adv>=0)&(ratio<=1.2))|((adv<0)&(ratio>=.8))
        ent=-(p*log).sum(1)
        loss=-sur.mean()+.25*((v-returns)**2).mean()-.01*ent.mean()
        dz=p.copy();dz[np.arange(n),a]-=1;dz*=(adv*ratio*active)[:,None]/n
        dz+=.01/n*p*(log+ent[:,None]);dv=(.5/n*(v-returns))[:,None]
        return float(loss),self.backprop(x,h,dz,dv),float(ent.mean()),float(np.mean((ratio-1)-(chosen-oldlog)))
