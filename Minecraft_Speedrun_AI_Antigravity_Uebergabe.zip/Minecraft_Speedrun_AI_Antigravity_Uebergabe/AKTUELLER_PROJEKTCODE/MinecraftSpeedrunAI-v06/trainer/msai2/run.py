import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,base64,csv,json,signal,time
from pathlib import Path
import numpy as np
from msai.env import Client,LabEnv
from .core import PPO,ACTIONS,NAMES,DIM,SCHEMA,encode,reward,gae

def log(path,row):
    exists=path.exists()
    with path.open('a',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,list(row))
        if not exists:w.writeheader()
        w.writerow(row)

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['train','evaluate']);p.add_argument('--game-dir',required=True)
    p.add_argument('--checkpoint',default='runs-v02/latest.npz');p.add_argument('--resume',action='store_true');p.add_argument('--episodes',type=int,default=100)
    p.add_argument('--stage',type=int,choices=range(4),default=0);p.add_argument('--policy',choices=['greedy','sample','random'],default='greedy')
    p.add_argument('--seed',type=int,default=19);p.add_argument('--test-start',type=int,default=100000);p.add_argument('--output',default='runs-v02')
    a=p.parse_args();training=a.mode=='train';ck=Path(a.checkpoint)
    if a.episodes<1 or a.test_start<100000:p.error('episodes must be positive; test-start >=100000')
    if training and ck.exists() and not a.resume:p.error('Checkpoint exists: use --resume. Never overwrite an existing model implicitly.')
    if not training and a.resume:p.error('--resume is only for training')
    meta={}
    if a.resume or (not training and a.policy!='random'):
        m,meta=PPO.load(ck)
        if meta.get('schema')!=SCHEMA or m.inputs!=DIM or m.actions!=5:raise ValueError('Use a v02 model; v01 remains a separate baseline.')
    else:m=PPO(DIM,5,seed=a.seed)
    rng=np.random.default_rng(a.seed)
    if training and 'scenario_rng' in meta:rng.bit_generator.state=meta['scenario_rng']
    stage=int(meta.get('stage',0)) if training else a.stage
    history=list(meta.get('history',[])) if training else []
    total=int(meta.get('episodes',0)) if training else 0;steps=int(meta.get('steps',0)) if training else 0
    out=Path(a.output)/f'{a.mode}-{time.strftime("%Y%m%d-%H%M%S")}-{time.time_ns()%1000000}'
    out.mkdir(parents=True);(out/'manifest.json').write_text(json.dumps(dict(**vars(a),schema=SCHEMA,model_hash=m.digest(),start_stage=stage),indent=2))
    client=Client(a.game_dir);fresh=LabEnv(a.game_dir,'instance-1');health=client.call('/health')
    if health.get('version')!='0.2.0':raise RuntimeError('Install msai-0.2.0-mc26.3.jar and remove the old msai JAR.')
    stopping=False
    def stop(*_):
        nonlocal stopping
        stopping=True;print('Stopping, saving model and releasing controls...',flush=True)
    signal.signal(signal.SIGINT,stop)
    def save():
        if training:m.save(ck,dict(schema=SCHEMA,episodes=total,steps=steps,stage=stage,history=history,scenario_rng=rng.bit_generator.state))
    batch=[];completed=0;initial=m.digest()
    if training and not a.resume:
        save()
        initial_path=ck.with_name(ck.stem+'-initial.npz')
        if not initial_path.exists():m.save(initial_path,dict(schema=SCHEMA,episodes=0,steps=0,stage=0,history=[],scenario_rng=rng.bit_generator.state))
    def update():
        if not batch:return
        x,actions,rs,vs,ds,lp=zip(*batch);adv,ret=gae(rs,vs,ds,0)
        metrics=m.optimize(np.stack(x),np.array(actions),ret,adv,np.array(lp));batch.clear()
        log(out/'updates.csv',dict(episodes=total,stage=stage,**metrics));save();print(f"PPO updates {m.updates}, changed={metrics['changed']}, entropy={metrics['entropy']:.3f}",flush=True)
    try:
        for ep in range(a.episodes):
            if stopping:break
            scenario=int(rng.integers(100000)) if training else a.test_start+ep
            fresh.last_frame=-1;raw=fresh.fresh(client.call('/reset',dict(scenario=scenario,stage=stage)));prev=encode(raw['agent']);obs=np.concatenate([prev,prev])
            (out/f'episode-{ep+1:04d}-start.ppm').write_bytes(b'P6\n32 18\n255\n'+base64.b64decode(raw['agent']['rgb']))
            start=time.monotonic();tick0=raw['trainer']['server_ticks'];maxsteps=[64,96,160,160][stage];score=0.;success=False;reason='interrupted';count=0
            for step in range(maxsteps):
                if stopping:break
                _,probs,values=m.forward(obs);probs=probs[0]
                if not training and a.policy=='random':action=int(rng.integers(5))
                elif training or a.policy=='sample':action=int(m.rng.choice(5,p=probs.astype('f8')/probs.sum(dtype='f8')))
                else:action=int(probs.argmax())
                old=raw['trainer']['distance'];before_obs=obs.copy();gold=any(r['block']=='minecraft:gold_block' for r in raw['agent']['rays'])
                raw=fresh.fresh(client.call('/step',dict(action=ACTIONS[action],ticks=4)));t=raw['trainer'];success=bool(t['success']);dead=bool(t['dead']);count=step+1
                limit=count>=maxsteps;wall_limit=time.monotonic()-start>=120;done=success or dead or limit or wall_limit
                r=reward(old,t['distance'],success,dead,done);score+=r;steps+=1
                current=encode(raw['agent']);obs=np.concatenate([prev,current]);prev=current
                log(out/'actions.csv',dict(episode=total+1 if training else ep+1,stage=stage,scenario=scenario,step=count,action=NAMES[action],probabilities=json.dumps(probs.tolist()),gold_visible=gold,distance_before=old,distance_after=t['distance'],reward=r,frame=raw['agent']['frame'],frame_age_ms=raw['agent']['frame_age_ms']))
                if training:batch.append((before_obs,action,r,float(values[0]),done,float(np.log(probs[action]+1e-9))))
                if done:
                    reason='success' if success else 'death' if dead else 'step_limit' if limit else 'wall_limit';break
            if reason=='interrupted':
                # Partial episode is discarded; already finished episodes remain valid.
                if training and count:del batch[-count:]
                break
            completed+=1;total+=int(training)
            log(out/'episodes.csv',dict(episode=total if training else ep+1,stage=stage,scenario=scenario,success=success,reason=reason,steps=count,wall_seconds=time.monotonic()-start,simulation_seconds=(raw['trainer']['server_ticks']-tick0)/20,reward=score,distance=raw['trainer']['distance'],model_hash=m.digest()))
            print(f"Episode {total if training else ep+1}, stage {stage}: {reason}; distance {t['distance']:.2f}",flush=True)
            if training:
                history=(history+[int(success)])[-40:]
                print(f'Last {len(history)} in this stage: {sum(history)} successes',flush=True)
                promote=stage<3 and len(history)==40 and sum(history)>=32
                if len(batch)>=128 or promote:update()
                if promote:
                    stage+=1;history=[];print(f'Curriculum advanced to stage {stage}',flush=True)
                save()
        if training:update()
        elif m.digest()!=initial:raise AssertionError('Evaluation modified model parameters')
    finally:
        try:save()
        finally:client.stop()
    print(f'Finished {completed} episodes. Logs: {out}',flush=True)
if __name__=='__main__':main()
