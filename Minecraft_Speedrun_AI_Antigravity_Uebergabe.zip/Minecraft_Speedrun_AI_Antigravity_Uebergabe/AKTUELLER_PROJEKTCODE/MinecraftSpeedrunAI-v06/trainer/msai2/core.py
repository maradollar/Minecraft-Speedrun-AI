"""Small CPU PPO policy. All decisions are learned; no scripted goal steering."""
import base64
import numpy as np
from msai.model import ActorCritic
ACTIONS=[{'forward':True},{'yaw':-20},{'yaw':20},{'forward':True,'yaw':-10},{'forward':True,'yaw':10}]
NAMES=['forward','left','right','forward_left','forward_right']
DIM=324
SCHEMA='v02-rgb8x6-rays7-state4-history2-actions5'

def encode(a):
    raw=np.frombuffer(base64.b64decode(a['rgb'],validate=True),np.uint8)
    if raw.size!=1728 or a['width']!=32 or a['height']!=18: raise ValueError('Invalid image dimensions')
    rgb=raw.reshape(6,3,8,4,3).mean((1,3)).ravel()/255-.5
    rays=np.array([[min(r['distance'],12)/12,float(r['block']=='minecraft:gold_block')] for r in a['rays']]).ravel()
    state=[a['health']/20,a['food']/20,np.clip(a['vx'],-1,1),np.clip(a['vz'],-1,1)]
    x=np.concatenate([rgb,rays,state]).astype('f4')
    if x.size!=162 or not np.isfinite(x).all():raise ValueError('Invalid observation')
    return x

def reward(old,new,success,dead,done):
    phi=-min(old,30)*.5
    next_phi=0 if done else -min(new,30)*.5
    return -.02+.99*next_phi-phi+(5 if success else -5 if dead else -3 if done else 0)

def gae(rewards,values,dones,last_value,gamma=.99,lam=.95):
    adv=np.zeros(len(rewards),dtype='f4');carry=0.;nv=last_value
    for i in range(len(rewards)-1,-1,-1):
        mask=1-float(dones[i]);delta=rewards[i]+gamma*nv*mask-values[i]
        carry=delta+gamma*lam*mask*carry;adv[i]=carry;nv=values[i]
    return adv,adv+np.asarray(values)

class PPO(ActorCritic):
    def objective(self,x,a,returns,adv,oldlog):
        h,p,v=self.forward(x);n=len(x);log=np.log(p+1e-9)
        chosen=log[np.arange(n),a];ratio=np.exp(chosen-oldlog)
        clipped=np.clip(ratio,.8,1.2);sur=np.minimum(ratio*adv,clipped*adv)
        active=((adv>=0)&(ratio<=1.2))|((adv<0)&(ratio>=.8))
        ent=-(p*log).sum(1)
        loss=-sur.mean()+.25*((v-returns)**2).mean()-.01*ent.mean()
        dz=p.copy();dz[np.arange(n),a]-=1;dz*= (adv*ratio*active)[:,None]/n
        dz+=.01/n*p*(log+ent[:,None])
        dv=(.5/n*(v-returns))[:,None]
        dh=(dz@self.p['wp'].T+dv@self.p['wv'].T)*(1-h*h)
        g={'w1':x.T@dh,'b1':dh.sum(0),'wp':h.T@dz,'bp':dz.sum(0),'wv':h.T@dv,'bv':dv.sum(0)}
        return float(loss),g,float(ent.mean()),float(np.mean((ratio-1)-(chosen-oldlog)))
    def optimize(self,x,a,returns,adv,oldlog):
        adv=(adv-adv.mean())/(adv.std()+1e-8);before=self.digest();loss=ent=kl=0.;batches=0
        for epoch in range(4):
            order=self.rng.permutation(len(x));stop=False
            for begin in range(0,len(x),64):
                ix=order[begin:begin+64]
                loss,g,ent,kl=self.objective(x[ix],a[ix],returns[ix],adv[ix],oldlog[ix])
                if not np.isfinite(loss+kl):raise FloatingPointError('Invalid PPO objective')
                if kl>.03:stop=True;break
                norm=np.sqrt(sum(float((v*v).sum()) for v in g.values()));scale=min(1,.5/(norm+1e-9));self.updates+=1
                for k in self.p:
                    grad=g[k]*scale;self.m[k]=.9*self.m[k]+.1*grad;self.v[k]=.999*self.v[k]+.001*grad*grad
                    self.p[k]-=self.lr*(self.m[k]/(1-.9**self.updates))/(np.sqrt(self.v[k]/(1-.999**self.updates))+1e-8)
                batches+=1
            if stop:break
        return dict(loss=loss,entropy=ent,kl=kl,batches=batches,updates=self.updates,changed=before!=self.digest())
