import argparse,json,base64
from pathlib import Path
from .env import Client
p=argparse.ArgumentParser();p.add_argument('--game-dir',required=True);p.add_argument('op',choices=['reset','observe','forward','look','jump','attack','use','open','close','click','stop','frame']);p.add_argument('--scenario',type=int,default=42);p.add_argument('--slot',type=int,default=9);p.add_argument('--button',type=int,choices=[0,1],default=0);a=p.parse_args();c=Client(a.game_dir)
try:
 if a.op=='reset':r=c.call('/reset',dict(scenario=a.scenario))
 elif a.op=='stop':r=c.stop()
 elif a.op in ['observe','frame']:
  r=c.call('/observe')
  if a.op=='frame':
   im=r['agent'];out=Path('runs/frame.ppm');out.parent.mkdir(exist_ok=True);out.write_bytes(b'P6\n32 18\n255\n'+base64.b64decode(im['rgb']));print('Saved',out)
 elif a.op in ['open','close']:r=c.call('/inventory',dict(op=a.op))
 elif a.op=='click':
  o=c.call('/observe');r=c.call('/inventory',dict(op='click',container_id=o['agent']['container_id'],slot=a.slot,button=a.button))
 else:r=c.call('/step',dict(action={'forward':dict(forward=True),'look':dict(yaw=30),'jump':dict(jump=True),'attack':dict(attack=True),'use':dict(use=True)}[a.op],ticks=10))
 if 'agent' in r:r['agent'].pop('rgb',None)
 print(json.dumps(r,indent=2))
finally:
 if a.op in ['forward','look','jump','attack','use']:c.stop()
