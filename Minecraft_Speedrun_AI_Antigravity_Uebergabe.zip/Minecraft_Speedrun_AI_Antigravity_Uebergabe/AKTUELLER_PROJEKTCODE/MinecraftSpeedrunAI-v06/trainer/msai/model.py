"""CPU actor-critic, analytic gradients and Adam. No pretrained weights."""
import hashlib,json,os
from pathlib import Path
import numpy as np

class ActorCritic:
 def __init__(self,inputs,actions,hidden=64,seed=7,lr=.0003):
  self.rng=np.random.default_rng(seed);self.inputs=inputs;self.actions=actions;self.hidden=hidden;self.lr=lr;self.updates=0
  self.p={'w1':(self.rng.standard_normal((inputs,hidden))/np.sqrt(inputs)).astype('f4'),'b1':np.zeros(hidden,'f4'),'wp':(self.rng.standard_normal((hidden,actions))*.01).astype('f4'),'bp':np.zeros(actions,'f4'),'wv':(self.rng.standard_normal((hidden,1))*.1).astype('f4'),'bv':np.zeros(1,'f4')}
  self.m={k:np.zeros_like(v) for k,v in self.p.items()};self.v={k:np.zeros_like(v) for k,v in self.p.items()}
 def forward(self,x):
  x=np.atleast_2d(x).astype('f4');h=np.tanh(x@self.p['w1']+self.p['b1']);z=h@self.p['wp']+self.p['bp'];z-=z.max(1,keepdims=True);p=np.exp(z);p/=p.sum(1,keepdims=True);v=(h@self.p['wv']+self.p['bv']).ravel();return h,p,v
 def choose(self,x,greedy=False):
  _,p,v=self.forward(x)
  return (p.argmax(1) if greedy else np.array([self.rng.choice(self.actions,p=row.astype('f8')/row.sum(dtype='f8')) for row in p])),v
 def gradients(self,x,actions,returns,advantages=None):
  x=np.asarray(x,'f4');a=np.asarray(actions,int);r=np.asarray(returns,'f4');h,p,v=self.forward(x);n=len(x);adv=r-v if advantages is None else advantages
  log=np.log(p+1e-9);ent=-(p*log).sum(1);loss=-(log[np.arange(n),a]*adv).mean()+.25*((v-r)**2).mean()-.02*ent.mean()
  dz=p.copy();dz[np.arange(n),a]-=1;dz*=adv[:,None]/n;dz+=.02/n*p*(log+ent[:,None]);dv=(.5/n*(v-r))[:,None];dh=(dz@self.p['wp'].T+dv@self.p['wv'].T)*(1-h*h)
  return float(loss),{'w1':x.T@dh,'b1':dh.sum(0),'wp':h.T@dz,'bp':dz.sum(0),'wv':h.T@dv,'bv':dv.sum(0)},float(ent.mean())
 def update(self,x,a,r):
  loss,g,entropy=self.gradients(x,a,r);norm=float(np.sqrt(sum(float((v*v).sum()) for v in g.values())))
  if not np.isfinite(loss+norm):raise FloatingPointError('Nonfinite loss/gradient')
  scale=min(1,.5/(norm+1e-9));self.updates+=1
  for k in self.p:
   grad=g[k]*scale;self.m[k]=.9*self.m[k]+.1*grad;self.v[k]=.999*self.v[k]+.001*grad*grad
   self.p[k]-=self.lr*(self.m[k]/(1-.9**self.updates))/(np.sqrt(self.v[k]/(1-.999**self.updates))+1e-8)
  return dict(loss=loss,entropy=entropy,gradient_norm=norm,updates=self.updates)
 def digest(self):return hashlib.sha256(b''.join(self.p[k].tobytes() for k in sorted(self.p))).hexdigest()
 def save(self,path,extra=None):
  path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.tmp')
  meta=dict(protocol=1,inputs=self.inputs,actions=self.actions,hidden=self.hidden,lr=self.lr,updates=self.updates,rng=self.rng.bit_generator.state,extra=extra or {})
  values={f'{prefix}_{k}':v for prefix,group in [('p',self.p),('m',self.m),('v',self.v)] for k,v in group.items()}
  with temp.open('wb') as f:np.savez_compressed(f,metadata=np.array(json.dumps(meta)),**values);f.flush();os.fsync(f.fileno())
  os.replace(temp,path)
 @classmethod
 def load(cls,path):
  with np.load(path,allow_pickle=False) as f:
   meta=json.loads(str(f['metadata']))
   if meta['protocol']!=1:raise ValueError('Wrong checkpoint format')
   m=cls(meta['inputs'],meta['actions'],meta['hidden'],lr=meta['lr'])
   for prefix,group in [('p',m.p),('m',m.m),('v',m.v)]:
    for k in group:
     value=f[f'{prefix}_{k}']
     if value.shape!=group[k].shape or not np.isfinite(value).all():raise ValueError('Invalid tensor '+k)
     group[k]=value.copy()
   m.updates=meta['updates'];m.rng.bit_generator.state=meta['rng']
  return m,meta['extra']
