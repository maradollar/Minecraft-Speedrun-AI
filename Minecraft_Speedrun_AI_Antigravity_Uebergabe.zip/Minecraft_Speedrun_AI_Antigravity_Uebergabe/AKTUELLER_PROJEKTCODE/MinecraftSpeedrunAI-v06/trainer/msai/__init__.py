"""Minecraft Speedrun AI, experimental learning lab 0.1.1."""
