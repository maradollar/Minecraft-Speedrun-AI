import base64,json,math,time,urllib.request,urllib.error
from pathlib import Path
import numpy as np
ACTIONS=[{},dict(forward=True),dict(back=True),dict(left=True),dict(right=True),dict(yaw=-20),dict(yaw=20),dict(forward=True,yaw=-10),dict(forward=True,yaw=10),dict(forward=True,jump=True)]
FRAME_DIM=454
INPUT_DIM=908
class Client:
 def __init__(self,game_dir):
  self.root=Path(game_dir).resolve();props={}
  for line in (self.root/'config/msai.properties').read_text().splitlines():
   if line and not line.startswith(('#','!')) and '=' in line:
    k,v=line.split('=',1);props[k.strip()]=v.strip()
  self.url='http://127.0.0.1:'+str(int(props['port']));self.token=props['token'];self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 def call(self,endpoint,data=None):
  req=urllib.request.Request(self.url+endpoint,json.dumps(data or {}).encode(),headers={'Authorization':'Bearer '+self.token,'Content-Type':'application/json'},method='POST')
  try:
   with self.opener.open(req,timeout=35) as f:r=json.load(f)
  except urllib.error.HTTPError as e:raise RuntimeError(e.read().decode(errors='replace')) from e
  if 'error' in r:raise RuntimeError(r['error'])
  return r
 def stop(self):return self.call('/stop')
def encode(a):
 raw=np.frombuffer(base64.b64decode(a['rgb'],validate=True),np.uint8)
 if raw.size!=32*18*3 or a['width']!=32 or a['height']!=18:raise ValueError('Unexpected image')
 rgb=raw.reshape(18,32,3).astype('f4').reshape(9,2,16,2,3).mean((1,3))/255-.5
 rays=[v for ray in a['rays'] for v in [min(ray['distance'],12)/12,float(ray['block']=='minecraft:gold_block')]]
 yaw=math.radians(a['yaw']);self_state=[a['health']/20,a['food']/20,math.sin(yaw),math.cos(yaw),a['pitch']/90,a['vx'],a['vy'],a['vz']]
 out=np.concatenate([rgb.ravel(),rays,self_state]).astype('f4')
 if out.size!=FRAME_DIM or not np.isfinite(out).all():raise ValueError('Invalid observation')
 return out
def reward(old,distance,success,dead,timeout,ticks=4,gamma=.99):
 phi=-min(old,30)/10;next_phi=0 if success or dead or timeout else -min(distance,30)/10
 return -.0025*ticks+gamma*next_phi-phi+(5 if success else -5 if dead else -2 if timeout else 0)
class LabEnv:
 def __init__(self,path,instance,max_steps=160):self.client=Client(path);self.instance=instance;self.max_steps=max_steps;self.last_frame=-1
 def fresh(self,r):
  end=time.monotonic()+5
  while True:
   a=r['agent']
   if 'rgb' in a and a['frame']>self.last_frame and a['frame_age_ms']<1000 and a['frame_tick']>=r['tick']-4:self.last_frame=a['frame'];return r
   if time.monotonic()>end:raise TimeoutError('No fresh image. Keep Minecraft visible, not minimized. Check latest.log and /health image_error.')
   time.sleep(.03);r=self.client.call('/observe')
 def reset(self,scenario):
  self.scenario=int(scenario);self.last_frame=-1;self.raw=self.fresh(self.client.call('/reset',dict(scenario=self.scenario)));self.previous=encode(self.raw['agent']);self.steps=0;self.started=time.monotonic();self.tick0=self.raw['trainer']['server_ticks'];self.total_reward=0
  return np.concatenate([self.previous,self.previous])
 def step(self,action):
  old=self.raw['trainer']['distance'];self.raw=self.fresh(self.client.call('/step',dict(action=ACTIONS[int(action)],ticks=4)));t=self.raw['trainer'];self.steps+=1
  success,dead=t['success'],t['dead'];timeout=self.steps>=self.max_steps or time.monotonic()-self.started>=120;done=success or dead or timeout;r=reward(old,t['distance'],success,dead,timeout);self.total_reward+=r
  current=encode(self.raw['agent']);obs=np.concatenate([self.previous,current]);self.previous=current;info={}
  if done:info=dict(instance=self.instance,scenario=self.scenario,success=success,deaths=int(dead),reason='success' if success else 'death' if dead else 'timeout',steps=self.steps,simulation_seconds=(t['server_ticks']-self.tick0)/20,wall_seconds=time.monotonic()-self.started,reward=self.total_reward,stage='navigation_lab',distance=t['distance'])
  return obs,r,done,info
