import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,csv,json,signal,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from .env import Client,LabEnv,ACTIONS,INPUT_DIM
from .model import ActorCritic

def log(path,row):
 exists=path.exists()
 with path.open('a',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,list(row))
  if not exists:w.writeheader()
  w.writerow(row)
def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['train','evaluate','play','diagnose','stop']);p.add_argument('--game-dir',nargs='+',required=True);p.add_argument('--checkpoint',default='runs/latest.npz');p.add_argument('--resume',action='store_true');p.add_argument('--random',action='store_true');p.add_argument('--episodes',type=int,default=100);p.add_argument('--max-steps',type=int,default=160);p.add_argument('--rollout',type=int,default=32);p.add_argument('--seed',type=int,default=7);p.add_argument('--output',default='runs');a=p.parse_args()
 if min(a.episodes,a.max_steps,a.rollout)<1:p.error('Counts must be positive')
 clients=[Client(path) for path in a.game_dir]
 if a.mode in ['diagnose','stop']:
  for c in clients:
   print(json.dumps(c.stop() if a.mode=='stop' else c.call('/health'),indent=2))
   if a.mode=='diagnose':
    r=c.call('/observe');r['agent'].pop('rgb',None);print(json.dumps(r,indent=2))
  return
 training=a.mode=='train'
 if not training and len(clients)!=1:p.error('Evaluate/play one instance for comparable tests')
 if len({c.url for c in clients})!=len(clients) or len({str(c.root) for c in clients})!=len(clients):p.error('Instances require unique directories AND ports')
 checkpoint=Path(a.checkpoint)
 if training and checkpoint.exists() and not a.resume:p.error('Checkpoint exists. Use --resume or another --checkpoint')
 if a.random and training:p.error('--random is for evaluation only')
 meta={}
 if a.resume or (not training and not a.random):m,meta=ActorCritic.load(checkpoint)
 else:m=ActorCritic(INPUT_DIM,len(ACTIONS),seed=a.seed)
 if m.inputs!=INPUT_DIM or m.actions!=len(ACTIONS):raise ValueError('Checkpoint schema mismatch')
 rng=np.random.default_rng(a.seed)
 if training and a.resume and 'scenario_rng' in meta:rng.bit_generator.state=meta['scenario_rng']
 out=Path(a.output);out.mkdir(parents=True,exist_ok=True);runid=time.strftime('%Y%m%d-%H%M%S');episode_file=out/f'{a.mode}-{runid}-episodes.csv';update_file=out/f'{a.mode}-{runid}-updates.csv'
 manifest=vars(a).copy();manifest.update(model_hash=m.digest(),updates=m.updates,schema='rgb16x9-rays7-self8-history2-v1')
 (out/f'{a.mode}-{runid}-manifest.json').write_text(json.dumps(manifest,indent=2))
 envs=[LabEnv(path,f'instance-{i+1}',a.max_steps) for i,path in enumerate(a.game_dir)]
 for e in envs:
  if e.client.call('/health').get('protocol')!=1:raise ValueError('Protocol mismatch')
 stopping=False
 def stop(*_):
  nonlocal stopping
  stopping=True;print('Stopping after current step; saving...',flush=True)
 signal.signal(signal.SIGINT,stop)
 completed=0;successes=0;steps=int(meta.get('steps',0)) if training else 0;old_episodes=int(meta.get('episodes',0)) if training else 0;start=time.monotonic();initial_hash=m.digest()
 def scenario():return int(rng.integers(0,100000))
 def save():m.save(checkpoint,dict(steps=steps,episodes=old_episodes+completed,scenario_rng=rng.bit_generator.state,stage='navigation_lab',schema=manifest['schema']))
 with ThreadPoolExecutor(max_workers=len(envs)) as pool:
  try:
   obs=list(pool.map(lambda pair:pair[0].reset(pair[1]),zip(envs,[scenario() if training else 100000 for _ in envs])))
   while completed<a.episodes and not stopping:
    xs=[];actions=[];rewards=[];dones=[]
    for _ in range(a.rollout if training else 1):
     if stopping:break
     x=np.stack(obs);ids=rng.integers(len(ACTIONS),size=len(envs)) if a.random else m.choose(x,greedy=not training)[0]
     results=list(pool.map(lambda pair:pair[0].step(pair[1]),zip(envs,ids)));xs.append(x);actions.append(ids);rewards.append([r[1] for r in results]);dones.append([r[2] for r in results]);obs=[r[0] for r in results];steps+=len(envs)
     for i,(_,_,done,info) in enumerate(results):
      if done:
       completed+=1;successes+=int(info['success']);log(episode_file,dict(episode=old_episodes+completed,**info,model_updates=m.updates,model_hash=m.digest()));print(f"Episode {completed}: {info['reason']} | {info['wall_seconds']:.1f}s | success {successes}/{completed}",flush=True)
       if completed<a.episodes and not stopping:obs[i]=envs[i].reset(scenario() if training else 100000+completed)
     if completed>=a.episodes:break
    if training and xs:
     bootstrap=m.forward(np.stack(obs))[2];returns=[]
     for r,d in zip(reversed(rewards),reversed(dones)):
      bootstrap=np.array(r,'f4')+.99*bootstrap*(1-np.array(d,'f4'));returns.append(bootstrap.copy())
     before=m.digest();metrics=m.update(np.concatenate(xs),np.concatenate(actions),np.concatenate(list(reversed(returns))));metrics.update(steps=steps,changed=before!=m.digest(),wall_seconds=time.monotonic()-start);log(update_file,metrics);save();print(f"Update {m.updates}: parameters_changed={metrics['changed']} entropy={metrics['entropy']:.3f}",flush=True)
   if not training and m.digest()!=initial_hash:raise AssertionError('Evaluation changed weights')
  finally:
   try:
    if training:save()
   finally:
    for e in envs:
     try:e.client.stop()
     except Exception as ex:print('Stop failed; watchdog releases controls:',ex)
 print(f'Done: {completed} episodes, {successes} successful. Logs: {episode_file}')
if __name__=='__main__':main()
