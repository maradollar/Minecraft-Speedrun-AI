@echo off
setlocal
cd /d "%~dp0"
set /p EXFILE=Vollstaendigen Pfad zur conversations.json eingeben: 
py -3 import_chatgpt_export.py "%EXFILE%"
if errorlevel 1 (
 echo Fehler. Pruefe Python und JSON-Pfad.
)
pause
