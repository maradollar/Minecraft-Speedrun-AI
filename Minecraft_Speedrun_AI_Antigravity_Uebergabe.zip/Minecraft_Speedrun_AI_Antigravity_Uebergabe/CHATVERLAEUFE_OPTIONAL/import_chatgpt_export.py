#!/usr/bin/env python3
"""Liest den selbst heruntergeladenen ChatGPT-Datenexport und rettet
NUR die sichtbaren User/Assistant-Texte aus passenden Minecraft Speedrun AI Chats.
Keine Netzwerknutzung; schreibt Markdown-Dateien lokal. Standardmäßig werden
keine fremden System-/Tool-Messages ausgegeben.
"""
import argparse, json, re, datetime, pathlib
MATCH_TITLE=re.compile(r'(speedrun|minecraft\s*(?:ki|ai)|minecraft.*selbstlern|selbstlern.*minecraft|minecraft.*cod)',re.I)
MATCH_BODY=re.compile(r'(MinecraftSpeedrunAI|reliability-v052|runs-v05|msai.?lab|minecraft.{0,60}(?:end(er)?drache|speedrun.?ki|selbstlern))',re.I|re.S)

def flatten(msg):
    if not isinstance(msg,dict):return ''
    data=msg.get('content') or {}
    parts=data.get('parts') if isinstance(data,dict) else None
    if not isinstance(parts,list):return ''
    return '\n'.join(str(p) for p in parts if isinstance(p,str)).strip()

def when(ts):
    try:return datetime.datetime.fromtimestamp(float(ts), datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    except:return 'unbekannt'

def safe(s):return re.sub(r'[^A-Za-z0-9_.-]+','_',s)[:70] or 'chat'

def main():
    p=argparse.ArgumentParser();p.add_argument('conversations_json',type=pathlib.Path);p.add_argument('--out',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent/'EXPORT_ORIGINAL_CHATS');p.add_argument('--include-all-minecraft',action='store_true'); args=p.parse_args()
    convs=json.loads(args.conversations_json.read_text(encoding='utf-8'))
    if not isinstance(convs,list): raise SystemExit('Erwarte ChatGPT-Export conversations.json mit einer Liste.')
    args.out.mkdir(parents=True,exist_ok=True)
    written=[]
    for c in convs:
        title=str(c.get('title') or 'Ohne Titel')
        mapping=c.get('mapping') or {}
        nodes=[]
        for id,node in mapping.items():
            msg=node.get('message') if isinstance(node,dict) else None
            if not isinstance(msg,dict):continue
            role=(msg.get('author') or {}).get('role')
            if role not in {'user','assistant'}:continue
            txt=flatten(msg)
            if not txt:continue
            nodes.append((msg.get('create_time') or 0,id,role,txt))
        body='\n'.join(x[3] for x in nodes)
        relevant=bool(MATCH_TITLE.search(title) or MATCH_BODY.search(body))
        if args.include_all_minecraft: relevant=relevant or 'minecraft' in title.lower()
        if not relevant:continue
        # Reduce alternate regenerated branches: follow current_node's parents where possible
        current=c.get('current_node')
        if current in mapping:
            parents=[]; seen=set()
            while current in mapping and current not in seen:
                seen.add(current); node=mapping[current]; msg=node.get('message') or {}
                role=(msg.get('author') or {}).get('role')
                txt=flatten(msg)
                if role in {'user','assistant'} and txt:parents.append((msg.get('create_time') or 0,current,role,txt))
                current=node.get('parent')
            nodes=list(reversed(parents))
        else: nodes.sort(key=lambda x:(x[0],x[1]))
        ident=str(c.get('id') or len(written)+1)[:20]
        fn=args.out/(safe(title)+'_'+safe(ident)+'.md')
        lines=[f'# {title}',f'Konversation-ID: {c.get("id") or "unbekannt"}',f'Export-Messages: {len(nodes)}','']
        for ts,nid,role,txt in nodes:
            lines += [f'## {"Nutzer" if role=="user" else "ChatGPT"} — {when(ts)}','',txt,'']
        fn.write_text('\n'.join(lines),encoding='utf-8');written.append(fn)
    index=args.out/'INDEX.md';index.write_text('# Exportierte Minecraft-Speedrun-AI-Chats\n\n'+('\n'.join(f'- [{f.stem}]({f.name})' for f in written) if written else 'Keine passenden Chats gefunden.')+'\n',encoding='utf-8')
    print(f'Exportiert: {len(written)} Chat(s) nach {args.out}')
if __name__=='__main__': main()
