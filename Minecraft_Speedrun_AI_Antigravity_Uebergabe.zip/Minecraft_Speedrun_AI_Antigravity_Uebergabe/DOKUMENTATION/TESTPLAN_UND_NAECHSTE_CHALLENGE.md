# Akzeptanztests und unverfälschte Messung

1. `unittest discover -s tests -v` mit `PYTHONPATH=trainer` und `.` als Projektverzeichnis. Die neun v06-Tests sind simuliert; **keine** echte Minecraft-Integration.
2. Java-JAR-Build falls nötig mit JDK 25, Hash der ausgelieferten JAR prüfen. Bericht in `TESTS.txt` beansprucht Code-Tests 9/9 und Build JDK 25.0.2.
3. In der separaten eigenen **MSAI_LAB**-Welt zuerst Helferfunktion/Reset und korrekte Mod-Version prüfen. Nicht in privaten Welten testen.
4. v06-Haupt-Challenge `01_HOLZ_CHALLENGES.cmd`: pro Stufe vier Lehrerchecks, 40 Lernepisoden, dann je 12 Model/Blind/Random. Keine Manipulation der Start-Szenen zugunsten des Modells. Bestehende Modelle eingefroren für Vergleich.
5. Promotion für die aktuelle Stufe erst bei Student >=10/12 und Student >= max(Blind+3, Random+3) und bestehenden Regression-Gates. Erfolgsdefinition: 1+ Eichenholz im Inventar.
6. Blocker separieren in: Reset/Bridge, Sehen/Zielwahl, Kameranachführung, Abbau, Drop-Aufnahme, Train/Eval-Leakage, Speicher-/Resume-Fehler.
7. Zusätzlich Nav-Kontrolle auf neuen Scenarios und Eisen-Failure-Analyse. Keine 4/8 Eisen zu 8/8 umdeuten.
8. Bei bestandenen Holz-Gates nächsten Skill implementieren, nicht nur planen: Baum → Holz → Bretter → Crafting-Tisch; echte Tests inkl. Inventory-UI in der gewählten Beobachtungsvorgabe. Falls UI mehr Pixel benötigt, Wahrnehmung so erweitern, dass Modell tatsächlich Bilder sieht.
9. Jeder Bericht: was implementiert / Tests wirklich ausgeführt / Ergebnisse mit Nenner und n / Baselines / Seed-Splits / Checkpoint-Pfade / Fehler und To-dos. Keine pauschale „alles funktioniert“-Aussage.
