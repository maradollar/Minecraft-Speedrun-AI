# Noch fehlende Originale (nicht als enthalten ausgeben)

Folgende fünf ZIP-Dateien wurden in der ChatGPT-Dateibibliothek eindeutig wiedergefunden, ließen sich jedoch aufgrund fehlender Freigabe für Rohdatei-Materialisierung hier **nicht als Bytes kopieren**. Sie sind in der Gesamt-ZIP NICHT enthalten:

- `reliability-v052.zip` – Nutzertests v0.5.2, hochgeladen 16.10.2026; ursprüngliche Datei ca. 8,4 MB. Die **Auswertung** befindet sich dennoch in v06 unter `AUSWERTUNG-v052.md`.
- `runs-v05.zip` – originale v0.5-Läufe vom 16.10.2026 (ca. 8,7 MB).
- `runs-v02(1).zip` – zweite v0.2-Testreihe vom 16.10.2026 (ca. 2,1 MB).
- `runs-v02.zip` – erste v0.2-Testreihe vom 16.10.2026 (ca. 1,5 MB).
- `runs.zip` – frühe Läufe vom 15.10.2026 (ca. 1,3 MB).

**Bitte diese ZIPs, falls noch lokal vorhanden, unverändert nach `TESTDATEN_EINFUEGEN/` kopieren.** Alternativ aus den betreffenden ursprünglichen Chatverläufen herunterladen. Keine Daten oder Ergebnisse daraus erfinden; bislang abgesicherte v052-Zahlen stammen aus dem dokumentierten Analysebericht.

Eine verbatim-Exportfunktion für alle bisherigen ChatGPT-Nachrichten wurde in dieser Sitzung nicht bereitgestellt. Daher enthält dieses Paket eine **inhaltlich umfassende Rekonstruktion**, aber **nicht** alle alten Worte und ChatGPT-Antworten. Wenn ein ChatGPT-Datenexport vorhanden ist, kann `CHATVERLAEUFE_OPTIONAL/import_chatgpt_export.py` relevante Gesprächsprotokolle aus `conversations.json` extrahieren und hier als Markdown speichern.

Bei Nutzerdateien können auch frühere, lokal nie hochgeladene Versionen existieren. Maßgeblich ist der tatsächliche lokale Projektordner; den vor Änderungen unbedingt einmal sichern.
