# Rekonstruierte Inhalte früherer ChatGPT-Unterhaltungen – NICHT wortgetreu

Diese Zusammenfassung stammt aus abrufbaren Gesprächsdetails und den Original-Archiven. Sie enthält keine automatisch erzeugten, erfundenen Transkripte. Für wortgetreue Rohchats siehe `CHATVERLAEUFE_OPTIONAL/import_chatgpt_export.py`.

## 14.10.2026: Anforderungen
- Nutzer möchte eine selbstlernende Minecraft-Java-KI, die auf festem Seed einen vollständigen Survival-Speedrun bis zum Enderdrachen schafft. Unterschiedliche Startpositionen und Situationen sollen durch Lernen gelöst werden.
- Vollständige Eingaben: Maus/Kamera, Tastatur, Bewegung, Inventar, Leben und Position in Training/Diagnose. Normale Launcher-Installation, lokal Windows 11, ein bis zwei Monitore vorhanden.
- Fokus Training mit Belohnung/Bestrafung (RL), Grundfähigkeiten zuerst (Crafting), dauerhafte Speicherung und mehrere Durchläufe, später parallel.
- Wichtig: keine vorgegebenen geheimen Erz-/Strukturkoordinaten; Training auf sichtbarer Weltinformation, nicht ein Skript für einen Seed.

## 14.–15.10.: Initiale Goldblock-Prototypen
- Erste Tests mit „1 von 9 success“, später ungefähr 70 Versuche; Modellstände wurden gesichert und neu gestartet.
- Nutzer berichtete 0/10 Erfolge, häufig Zeitüberschreitungen/Goldblock nicht erkannt oder falsche Steuerung.
- Nutzer wollte sehen, ob KI *wirklich Bilder* empfängt; Bildvorschau/Testmöglichkeit, ggf. 1920×1080 und Fenster-/Tab-Aufnahme. Wichtig: tatsächliche Modelleingabeauflösung unterscheiden von sichtbarer Bildschirmauflösung.
- Fragen, ob gleichzeitig Minecraft spielbar sei. Sicherheitsregel: dieselbe Trainingsinstanz nicht parallel bedienen.

## 16.10.: Zuverlässigkeit + zunehmende Schwierigkeit
- Nutzer stellte `runs-v02.zip` und `runs-v02(1).zip` bereit; daraus sollen echte Probleme identifiziert und neue Versionen gebaut werden.
- Paket v0.3.0 `Navigation`, v0.4.0 `Bildlernen`, v0.5.0 `Zielnavigation` mit vier Zielblöcken und wiederverwendbarer Skill-Schnittstelle.
- Nutzer: keine bloße Bestandsbeschreibung; immer Fehler beheben, neue Version, neue Tests/Challenges programmieren.
- Nach `runs-v05.zip` und v05-Updates: Patch 0.5.1 Vorschau und Patch 0.5.2 Eisen-Zuverlässigkeit. Nutzer verlangt, bei guten Ergebnissen nächste KI zu entwickeln, statt endlos weiter zu optimieren.
- `reliability-v052.zip` dokumentiert in späterer Archiv-Auswertung 28/32 autonome Erfolge (87,5 %) nach Verbesserung; Eisen weiterhin 4/8.
- Letzte Version v0.6.0 `Holz-Challenges` erzeugt: eigenes Lern-Curriculum Eichenstamm finden, abbauen und Item einsammeln. Code/JAR und vortrainiertes v052-Navigationsmodell geliefert; unabhängiger Holz-Minecraft-Test noch nicht abgeschlossen.

## Verbindliche Form des künftigen Arbeitsauftrags
- Bitte nicht nur Fehler analysieren, sondern bei hinreichender Funktionsfähigkeit direkt **eine andere, schwierigere Art von Aufgabe** mit neuem Code und automatischen Tests implementieren.
- Direkte implementierte Lösungen, vollständiger Code (ggf. lauffertige Mod-JAR) + wenige nötige Handgriffe unter Windows.
- Belastbare Testberichte, kleine verständliche Schrittfolgen, automatische Checkpoints, keine erfundenen Trainingsergebnisse.
