# Windows: So übergibst du die Dateien an Antigravity

1. **Dieses Übergabe-ZIP** nach `C:\MC-AI-Uebergabe` entpacken (nicht direkt in deinen bestehenden `instance1/mods`-Ordner).
2. **Google Antigravity starten** und über „Open Folder“ den ausgepackten Ordner `Minecraft_Speedrun_AI_Antigravity_Uebergabe` öffnen. Die Datei `ANTIGRAVITY_START_HIER.md` als erste Anweisung an den Agenten schicken.
3. Der Quellcode unter `AKTUELLER_PROJEKTCODE/MinecraftSpeedrunAI-v06` ist die neueste Basis. Antigravity soll darin arbeiten. `VERSIONEN_ORIGINAL_ZIPS` sind unveränderte Archivkopien.
4. **Optional aber hilfreich:** Falls noch auf deinem PC vorhanden, die Dateien `reliability-v052.zip`, `runs-v05.zip`, `runs-v02.zip`, `runs-v02(1).zip`, `runs.zip` in `TESTDATEN_EINFUEGEN` legen.
5. Um zusätzlich wortgetreue Chatverläufe zu liefern, **selbst** den Datenexport von ChatGPT anfordern (ChatGPT → Einstellungen → Datenkontrollen → Daten exportieren; die Menübezeichnungen können sich ändern). Export herunterladen und `conversations.json` aus der Export-ZIP entpacken. Dann die beiliegende `CHATVERLAEUFE_OPTIONAL/IMPORT_CHATS.cmd` starten und Pfad zu `conversations.json` angeben. Danach Antigravity bitten, `CHATVERLAEUFE_OPTIONAL/EXPORT_...` zu lesen.
6. Den Antigravity-Agenten zuerst vorhandene Python-Tests ausführen lassen. **Erst danach** Änderungen an Minecraft-Instanz/Java-Mod; bei jeder Installeraktion den genauen Zielordner `C:\MC-AI\instance1` verifizieren und Backup prüfen.
7. Nicht blind sämtliche ZIPs gleichzeitig entpacken: ältere Patches/Java-Mod-JARs könnten neuere Dateien überschreiben.

Wichtig: Die v06-Dokumentation benutzt als Vorzustand die bestehende Python-Umgebung `C:\MC-AI\MinecraftSpeedrunAI\.venv`. Falls dein Pfad anders ist, muss `settings.cmd` vor dem Start angepasst werden. Nur eine MSAI-JAR gleichzeitig installieren. Minecraft/Training nicht parallel manuell bedienen.
