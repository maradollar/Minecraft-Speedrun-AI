# PROJEKTÜBERGABE – Minecraft Speedrun AI

**Stand:** 16. Oktober 2026 (Europe/Berlin)  
**Quelle:** rekonstruierter Verlauf aus ChatGPT-Gesprächskontext; geprüfte Inhalte der verfügbaren Projekt-ZIPs v0.1.1–v0.6.0.  
**Ziel:** Google Antigravity soll die bestehende Codebasis analysieren, fortführen, testen und echte Fortschritte nachweisen – ohne funktionierende Teile zu ersetzen.

## 1. Das eigentliche Nutzerziel

Eine lokal laufende, kostenlos nutzbare, **wirklich selbstlernende** Minecraft-Java-KI, die in Survival auf einem fest vorgegebenen Seed trotz veränderter Ausgangssituationen zunehmend selbstständig handelt und langfristig den Enderdrachen besiegt. Kein reiner Skript-Speedrun und keine Folge hartkodierter Goldblock-Klicks. Sie soll aus Erfahrungen lernen, Modelle dauerhaft speichern und Fähigkeiten wiederverwenden. Im Endzustand gehören Wahrnehmung, Bewegung/Kamera, Ressourcenabbau, Inventar, Crafting, Kampf, Überleben, Nether, Stronghold, End und Drachenkampf dazu.

Die Policy soll ihre Entscheidungen grundsätzlich aus **sichtbaren Spielbildern und ihren eigenen Aktionen/Zielaufträgen** treffen, nicht aus der exakten Lage von Erzen, Strukturen oder geheimen Weltkoordinaten. Die Trainingsumgebung darf zur Reset-Steuerung und Erfolgsmessung zusätzliche Zustandsinformationen sehen. Ein programmierter Lehrer darf im Training Labels liefern, aber **nicht stillschweigend während eigenständiger Evaluation Entscheidungen übernehmen**. Frühe Entwürfe ließen zusätzliche Telemetrie als Modelleingang zu; die verbindliche spätere Richtung ab v0.5.0 ist ausdrücklich bildbasiert. Etwaige Abweichungen sauber dokumentieren.

### Harte Anforderungen an Entwickler-Agenten
- Primär vollständig implementieren, nicht nur Ideen und lange Bestandsaufnahmen ausgeben.
- Auf den vorhandenen Projektdateien aufbauen und funktionierende Komponenten erhalten.
- Fehler anhand tatsächlicher Logs und Tests diagnostizieren; keine unbelegten Erfolgsmeldungen.
- Bei ausreichend stabilen Fähigkeiten **zum nächsten neuen, schwierigeren Fähigkeitsbereich übergehen**, statt nur denselben Test zu wiederholen.
- Neue KI/Challenge wirklich implementieren samt CMD-Startdatei, automatisierten Tests, Logs, Checkpoints und verständlicher Windows-Anleitung.
- Erfolg selbstständig und fair gegen Baselines (Lehrer, random, blind) prüfen. Lehrererfolg ist kein eigenständiger Modell-Erfolg.
- Nur kostenlose Werkzeuge/Abhängigkeiten; möglichst lokal und CPU-tauglich, keine CUDA-/Cloud-Pflicht.
- Sicherheitsgrenzen: normale eigene Singleplayer-Trainingswelt, nicht öffentliche Server oder fremde Welten verändern; keine Zugangstokens in Zips.

## 2. Lokale Zielumgebung und Bedienung

- Betriebssystem: Windows 11. Normaler Minecraft Launcher, Minecraft **Java Edition**.
- Bisherige gebaute Mod laut v06-README für Minecraft **26.3**, Fabric Loader **0.19.5**, JDK **25** (in v06 laut Bericht JDK 25.0.2). Kompatibilität mit tatsächlich installiertem Launcher prüfen, nicht eine andere Version voraussetzen.
- Früher genannte Hardware: Ryzen 5 5600X, 32 GB RAM. Die GPU wurde in Gesprächen widersprüchlich genannt (RX 7600 XT, später RX 6500 XT). Für den Trainer ist laut v05/v06 keine dedizierte ML-GPU nötig; kein GPU-Typ ungeprüft fest verdrahten.
- Frühere Ordner laut Projektdokumenten: `C:\MC-AI\instance1` = Minecraft-Laborinstanz mit `mods`, `config`, `saves`; `C:\MC-AI\MinecraftSpeedrunAI\.venv\Scripts\python.exe` = Python-Umgebung; neue Versionen als separate `C:\MC-AI\MinecraftSpeedrunAI-v05`/`-v06`.
- Weltname: **MSAI_LAB**. Nicht in einer wertvollen Survival-Welt trainieren.
- Bildschirmvorlage in v05/v06: FOV 90, Standardtexturen, keine Shader; Spiel sichtbar lassen, Menüs zu, während Trainer läuft nicht manuell steuern.
- Steuerung: vollautomatisierte Aktionen über Client-Mod-Bridge; schon vorhanden sind u.a. Bewegung, Angriff, Blickrichtung, Hotbar/Inventar-Schnittstellen (nicht alle durch gelernte Skills erprobt).
- Training pausieren: Strg+C und Speichern abwarten. Nur ein Trainer pro Instanz. Andere MSAI-JAR sichern; nie zwei MSAI-Modversionen im `mods`-Ordner gleichzeitig.

## 3. Verifizierbare Chronologie

| Zeitraum/Version | Umsetzung bzw. berichteter Verlauf | Einschränkung |
|---|---|---|
| 14.–15.10.: Konzeption | Vollständige Steuerung, Singleplayer Java, feste Seeds, variierender Start; RL/Imitation/Demonstrationsideen, Speichern und autonome Tests. | Langfristiges Ziel, nicht Gesamtumsetzung. |
| 0.1.1 (15.10.) | Fabric-Brücke + Python-Trainer, anfängliche Goldblock-Aufgabe, ausführbarer Quellcode/JAR. | Früher Zustand; Nutzer sah Timeout-/Erkennungsprobleme, u.a. 0/10. |
| 0.2.0 (16.10.) | Goldblock-Navigation als Curriculum, PPO/GAE/Adam, Reset und Baseline-Vergleich. | Modellsicht nutzte RGB-Downsample **und sieben Sichtstrahlen/Telemetrie**; noch keine reine Bilderkennung. Vorher ca. 70 Versuche gemeldet. |
| 0.3.0 (16.10.) | Navigation weiterentwickelt, separate CMD-Trainings- und Vergleichsbefehle, optionaler RL-Schritt. | Prüfungen auf dem eigenen PC erforderlich. |
| 0.4.0 (16.10.) | Bildlernen/Bildvorschau, 64×36-basierte visuelle Navigation. | Nutzer wollte sehen, welche Bilder die KI tatsächlich erhält. |
| 0.5.0 (16.10.) | Wiederverwendbare `navigate_to_block(Ziel)`-Fähigkeit mit Gold, Eisen, Smaragd, Eichenstamm; zwei aufeinanderfolgende 64×36-RGB-Bilder + Zielslot + letzte Aktion; Nachahmungslernen; unabhängiger Vergleich teacher/student/random/blind. | Nicht bereits vollständige Speedrun-KI. |
| 0.5.1 Patch | Reparaturen der Bildvorschau und Tests. | Patch auf v05 anwenden, falls dieser Stand separat benötigt wird. |
| 0.5.2 Patch | Eisen-/Zuverlässigkeitsdiagnose, Trainings- und Test-Routinen. | Eisen blieb selbst nach zusätzlichen Tests problematisch. |
| 0.5.2 Testauswertung | `reliability-v052.zip` wurde damals analysiert; die zusammenfassende originale Analyse liegt **im v06-Archiv** unter `AUSWERTUNG-v052.md`. | Rohdaten-Archiv ist hier NICHT mitübertragbar; siehe Fehlliste. |
| 0.6.0 (16.10.) | Holz-Challenges Stufe 4–6: Eichenholz aus Bild erkennen/ansteuern, Stamm abbauen und Item aufnehmen; vortrainierte Navigationsgewichte aus v052 als Seed, neuer Ressourcenkopf, neue JAR, CMD-Launcher und 9 synthetische Unit-Tests. | Holz-Training im realen Minecraft ist **noch nicht belegt**. Noch keine trainierten Holzgewichte. |

## 4. Messwerte aus der vorhandenen v052-Auswertung

Quelle: `AKTUELLER_PROJEKTCODE/MinecraftSpeedrunAI-v06/AUSWERTUNG-v052.md` (ursprünglich im v06-ZIP, nicht neu geschätzt).

| Zielklasse | Vorher (von 8) | Nachher (von 8) |
|---|---:|---:|
| Gold | 6 | 8 |
| Eisen | 4 | 4 |
| Smaragd | 8 | 8 |
| Eiche | 7 | 8 |
| **Gesamt** | **25/32 = 78,1 %** | **28/32 = 87,5 %** |

- Trainierte/unterstützte Trainingsläufe mit Lehrer: 32/32; **nicht mit selbstständiger Erfolgsquote verwechseln**.
- Mittlere Spielzeit: 7,90 s → 5,15 s. Richtungswechsel absolut: 743 → 465; in Relation zu Aktionen aber nur 33,7 % → 32,8 %, daher keine erwiesene starke Feinsteuerungsverbesserung.
- Vier Eisen-Szenarien weiterhin problematisch; vor/nach teils verschiedene Fehlerfälle. Keine pauschale Behauptung stabiler Eisen-Navigation.
- Diese 32 Evaluationsversuche sind nur ein kleiner Entwicklungsvergleich; keine belastbare Generalisierung auf alle Situationen.

## 5. **Verbindlicher technischer IST-Zustand v0.6.0**

- Funktionierende Offline-**Codebasis**: Java-Fabric-Mod-Quellen und gebaute `dist/msai-0.6.0-mc26.3.jar`; Python `trainer` und `challenge.py`; Windows-CMD-Starter; `seed/navigation-v052.npz`.
- Modell-Eingabe laut v06-README/`msai6/core.py`: zwei 64×36×3-RGB-Bilder, Zielauftrag (16-Slot-Katalog), vorherige Aktion; keine geheimen Block-IDs, Weltkoordinaten oder Raycasts im unabhängigen Policy-Pfad.
- Modell lernt mit NumPy auf CPU; gelernte 4×4-Stride-4-Bildfilter, Hidden- und Policy-Kopf; sieben Aktionen `forward`, `left`, `right`, `up`, `down`, `mine`, `back`.
- Abbau-Aktion hält Angriff 70 Ticks. Die Policy wählt **wann**, nicht die Dauer (derzeit fest programmiert).
- Drei neue Stufen: (4) Abbau/Aufnahme aus nächster Nähe, (5) aus Distanz mit Navigation, (6) Eichenstamm aus gemischten Gold-/Eisen-/Smaragd-/Eichen-Zielen auswählen, abbauen und aufnehmen.
- Pro Stufe: erst 4/4 Helfertests; dann 40 Imitation-Episoden (erste 12 mit Helfer); dann 12 unabhängige Modelltests + je 12 Blind- und Zufallstests. Gate: mindestens 10/12 Modell, mindestens 3 mehr als beide Kontrollen. Nach höheren Stufen Wiederholung zuvor bestandener Holzstufen.
- Tatsächlicher Erfolg erfordert **mindestens ein Eichenholzitem im Inventar**, nicht bloß verschwundenen Stamm.
- Speichern nach jeder Episode, Wiederaufnahme `runs-v06/resource.npz`, getrennte passierte Checkpoints, `runs-v06/result.json`.
- Bei Windows/Minecraft in dieser Übergabe **nicht erneut live getestet**. Im ursprünglichen v06-Bericht: 9/9 automatische Tests bestanden, JAR mit JDK 25.0.2 gebaut; Tests verwendeten synthetische Bilder und eine simulierte Bridge. Keine Aussage über echten Holz-Lernerfolg.
- `03_NAVIGATION_KONTROLLE.cmd` misst Navigation aus eingefrorenem v052-Modell auf 16 neuen Szenarien; verändert das Holzmodell nicht.
- Originale v06-Dokumentation ist die maßgebliche Datei für genaue Installation, Befehle und Grenzen. **Nicht einfach v05-Patches auf v06 überschreiben.**

## 6. Was noch **nicht** als gelernt oder gebaut gelten darf

- Erfolgreiches autonomes Holzabbauen / Aufnehmen auf echtem Minecraft nach v06: **offen**.
- Crafting-Pipeline / Inventarsteuerung als gelerntes Modul: **offen**.
- Adaptive Kampfpolicy, Ernährung, Hunger, Überleben, Tod/Respawn: **offen**.
- Freie Wald-/Terrain-Navigation, robuste Gegner-/Hinderniserkennung: **offen**.
- Automatisierter mehrstufiger Survival-Speedrun, Nether, Blazes/Enderperlen, Stronghold, End/Drache: **offen**.
- Langzeitgedächtnis, hochauflösende Inventar-OCR/Visualisierung, Multi-Instanz-PPO: **nicht im v06-Paket ausgewiesen**.
- Optionale RL-Pfade in älteren Versionen dürfen nicht als RL-Training der neuen Holzpolicy ausgegeben werden; v06 lernt primär durch Imitation.

## 7. Arbeitsweise für die **nächste** Antigravity-Entwicklung

1. Den Code unter `AKTUELLER_PROJEKTCODE/MinecraftSpeedrunAI-v06` und die originalen READMEs/Testroutinen lesen, v06 als Hauptstand behandeln.
2. Erst Code-Tests und Abhängigkeiten prüfen, **ohne** eigenmächtig das reale Minecraft/Mods/Spielwelten zu verändern. Auf Windows die installierte Java-, Fabric- und Python-Konfiguration auslesen.
3. v06-Helfertests mit echter Trainingswelt ausführen, dann Modell-/Blind-/Random-Läufe und Logs speichern. Fehler nach **Zielerkennung, Blickkorrektur, Abbau, Itemaufnahme** differenzieren.
4. Wenn Stufen 4–6 bestehen, **sofort** einen neuen, anspruchsvolleren Skill implementieren (empfohlen: Holz zu Brettern → Crafting-Tisch; danach Werkzeug und Ressourcen). Neue Aufträge, tatsächlich gelernte Handlungen, Train/Eval-Kontrollgruppen, Checkpoints, Windows-Starts, Progression und Regressionstest.
5. Wenn nicht bestanden: Ursache mit Daten benennen, gezielt korrigieren; keine endlosen Trainingsblöcke, kein generalisiertes Gelingen behaupten.
6. Den Eisenziel-Schwachpunkt separat mit bildbasierter Diagnose und neuen, fairen Szenarien prüfen, ohne Verbesserungen der Holzfähigkeit zu verzögern, sofern unabhängige Gates dafür bestanden sind.
7. Nutzer will möglichst direkt den **fertigen Code/Mod/JAR, Tests und eine einfache Schritt-für-Schritt-Anleitung**. Keine langatmige Zusammenfassung ohne Implementierung.

## 8. Vertrauens-/Quellentrennung

- **Direkt in Archiv geprüft:** Dateinamen, Quellcode, v06 README, Code-Testbericht, v052-Testauswertung, Versionen/Patches.
- **Rekonstruiert aus Gesprächen:** Benutzerziele, chronologische Entwicklungswünsche, frühe Timeout-/Goldblock-Probleme, gemeldete ca. 70 Versuche, Hardwareangaben und Arbeitspräferenzen.
- **Nicht verfügbar in dieser Übergabe:** exakte komplette ChatGPT-Rohgespräche und fünf nutzerhochgeladene Logs-ZIPs (Details in `FEHLENDE_DATEIEN.md`). Sie sind nicht mit anderen Inhalten zu verwechseln.
